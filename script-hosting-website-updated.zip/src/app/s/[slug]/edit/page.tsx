import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { EditForm } from "@/components/edit-form";
import { ensureSeeded } from "@/db/seed";
import { getSessionUser } from "@/lib/auth";
import { getScriptBySlug } from "@/lib/queries";
import { getBaseUrl } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "编辑脚本",
  robots: { index: false, follow: false },
};

type PageProps = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function EditScriptPage({ params, searchParams }: PageProps) {
  await ensureSeeded();
  const { slug } = await params;
  const query = await searchParams;
  const rawKey = Array.isArray(query.key) ? query.key[0] : query.key;
  const editKey = (rawKey ?? "").trim();

  const script = await getScriptBySlug(slug);
  if (!script) notFound();

  const baseUrl = await getBaseUrl();
  const user = await getSessionUser();
  const isOwner = Boolean(user && script.ownerId === user.id);

  return (
    <div className="mx-auto max-w-6xl px-5 py-10">
      <nav className="flex flex-wrap items-center gap-1.5 font-mono text-[11px] text-zinc-600">
        <Link href="/manage" className="hover:text-zinc-300">manage</Link>
        <span>/</span>
        <Link href={`/s/${slug}`} className="hover:text-zinc-300">{slug}</Link>
        <span>/</span>
        <span className="text-zinc-400">edit</span>
      </nav>

      <div className="mt-4 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-2">/ editor</p>
          <h1 className="mt-2 text-[28px] font-semibold tracking-tight text-white">编辑脚本</h1>
          <p className="mt-2 text-[13px] text-zinc-500">
            短链 <code className="font-mono text-zinc-300">{slug}</code> 保持不变，更新后立即生效。
          </p>
        </div>
        <Link href={`/s/${slug}`} className="btn btn-ghost">查看脚本页 ↗</Link>
      </div>

      <div className="mt-8">
        {editKey || isOwner ? (
          <EditForm
            initial={{
              slug: script.slug,
              title: script.title,
              description: script.description,
              authorName: script.authorName,
              tags: script.tags,
              code: script.code,
              visibility: script.visibility,
              obfuscation: script.obfuscation,
              inflation: script.inflation,
            }}
            editKey={editKey}
            isOwner={isOwner}
            baseUrl={baseUrl}
          />
        ) : (
          <div className="card mx-auto max-w-md p-6 text-center">
            <span className="mx-auto grid h-11 w-11 place-items-center rounded-xl border border-line bg-white/[0.03] text-lg text-zinc-400">
              ⌘
            </span>
            <h2 className="mt-4 text-[15px] font-semibold text-white">需要编辑密钥</h2>
            <p className="mt-2 text-[12.5px] leading-relaxed text-zinc-500">
              出于安全考虑，编辑脚本需要创建时生成的密钥。你可以从这里输入密钥，或前往「我的托管」。
            </p>
            <form action={`/s/${slug}/edit`} method="get" className="mt-4 space-y-2 text-left">
              <label className="label" htmlFor="key">编辑密钥</label>
              <input id="key" name="key" type="password" required placeholder="粘贴创建时的密钥" className="field font-mono !text-[12px]" />
              <button type="submit" className="btn btn-primary w-full">验证并编辑</button>
            </form>
            <Link href="/manage" className="mt-3 inline-flex text-[12px] text-brand-2 hover:underline">
              打开我的托管 →
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
