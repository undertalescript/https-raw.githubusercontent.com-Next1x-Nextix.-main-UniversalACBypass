import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { headers } from "next/headers";
import { CodeView } from "@/components/code-view";
import { CommentForm } from "@/components/comment-form";
import { CopyButton } from "@/components/copy-button";
import { LikeButton } from "@/components/like-button";
import { LoadstringPanel } from "@/components/loadstring-panel";
import { ScriptCard } from "@/components/script-card";
import { ensureSeeded } from "@/db/seed";
import { hashVisitor } from "@/lib/api-helpers";
import { getSessionUser, isAdminUser } from "@/lib/auth";
import { formatDate, formatNumber, initialOf, timeAgo } from "@/lib/format";
import {
  getComments,
  getRelatedScripts,
  getScriptBySlug,
  hasLiked,
  registerView,
} from "@/lib/queries";
import { getBaseUrl } from "@/lib/site";
import { getSiteSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  try {
    const script = await getScriptBySlug(slug);
    if (!script) return { title: "脚本不存在" };
    return {
      title: script.title,
      description: script.description || `${script.authorName} 托管的 Luau 脚本，支持 loadstring 直接执行。`,
      openGraph: { title: script.title, description: script.description },
    };
  } catch {
    return { title: "脚本" };
  }
}

export default async function ScriptDetailPage({ params }: PageProps) {
  await ensureSeeded();
  const { slug } = await params;
  const script = await getScriptBySlug(slug);
  if (!script) notFound();

  await registerView(script.id);

  const headerStore = await headers();
  const ip =
    (headerStore.get("x-forwarded-for") ?? "").split(",")[0]?.trim() ||
    headerStore.get("x-real-ip") ||
    "anonymous";
  const viewerHash = hashVisitor(ip, headerStore.get("user-agent") ?? "unknown");

  const [comments, related, liked, baseUrl, user, settings] = await Promise.all([
    getComments(script.id),
    getRelatedScripts(script, 3),
    hasLiked(script.id, viewerHash),
    getBaseUrl(),
    getSessionUser(),
    getSiteSettings(),
  ]);

  const blockedReason = !settings.scriptsEnabled
    ? "站长已暂停全站脚本执行，现在运行只会打印提示，不会执行代码。"
    : script.disabled
      ? "该脚本已被站长停用，现在运行只会打印提示。"
      : null;

  const isOwner = Boolean(user && script.ownerId === user.id);
  const canViewSource = isOwner || isAdminUser(user);

  const pageUrl = `${baseUrl}/s/${script.slug}`;
  const views = script.views + 1;

  return (
    <div className="mx-auto max-w-6xl px-5 py-8">
      {/* Breadcrumb */}
      <nav className="flex flex-wrap items-center gap-1.5 font-mono text-[11px] text-zinc-600">
        <Link href="/" className="hover:text-zinc-300">home</Link>
        <span>/</span>
        <Link href="/scripts" className="hover:text-zinc-300">scripts</Link>
        <span>/</span>
        <span className="truncate text-zinc-400">{script.slug}</span>
        {script.visibility === "unlisted" && (
          <span className="ml-2 rounded border border-amber-400/30 bg-amber-400/10 px-1.5 py-0.5 text-[10px] text-amber-300">
            unlisted
          </span>
        )}
      </nav>

      {/* Title */}
      <header className="mt-4">
        <div className="flex flex-wrap items-center gap-1.5">
          {script.tags.map((tag) => (
            <Link key={tag} href={`/scripts?tag=${encodeURIComponent(tag)}`} className="chip hover:border-brand/50 hover:text-brand-2">
              {tag}
            </Link>
          ))}
          <span className="chip font-mono">{script.language}</span>
        </div>
        <h1 className="mt-3 text-[clamp(1.6rem,3.6vw,2.3rem)] font-semibold leading-tight tracking-tight text-white">
          {script.title}
        </h1>
        {script.description && (
          <p className="mt-3 max-w-3xl text-[13.5px] leading-relaxed text-zinc-400">{script.description}</p>
        )}
        <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-[11.5px] text-zinc-500">
          <span className="flex items-center gap-2">
            <span className="grid h-6 w-6 place-items-center rounded-full bg-brand/20 font-mono text-[10px] text-brand-2">
              {initialOf(script.authorName)}
            </span>
            <span className="text-zinc-300">{script.authorName}</span>
          </span>
          <span className="text-zinc-700">·</span>
          <span>发布于 {formatDate(script.createdAt)}</span>
          <span className="text-zinc-700">·</span>
          <span>更新于 {timeAgo(script.updatedAt)}</span>
          <span className="text-zinc-700">·</span>
          <span className="font-mono">👁 {formatNumber(views)}</span>
          <span className="font-mono">▶ {formatNumber(script.runs)}</span>
        </div>
      </header>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_320px] lg:items-start">
        <div className="min-w-0 space-y-6">
          <section>
            <div className="mb-2 flex items-center justify-between">
              <h2 className="text-[13px] font-semibold text-zinc-300">执行方式</h2>
              <span className="font-mono text-[10.5px] text-zinc-600">text/plain · UTF-8</span>
            </div>
            {blockedReason && (
              <div className="mb-2 flex items-start gap-2 rounded-xl border border-rose-500/30 bg-rose-500/[0.08] px-3.5 py-2.5">
                <span className="mt-0.5 text-[11px] text-rose-300">●</span>
                <p className="text-[11.5px] leading-relaxed text-rose-200/90">{blockedReason}</p>
              </div>
            )}
            <div className="mb-2 flex flex-wrap items-center gap-x-3 gap-y-1 rounded-xl border border-lime/20 bg-lime/[0.05] px-3.5 py-2.5">
              <span className="text-[11px] text-lime-300">✓</span>
              <p className="text-[11.5px] leading-relaxed text-zinc-400">
                已兼容 Delta / Ninja / Solara / Wave 等执行器：复制下方<b className="text-zinc-200">整段</b>代码即可，
                请勿在浏览器里打开直链（会显示 403，这是保护生效）。
              </p>
            </div>
            <LoadstringPanel slug={script.slug} baseUrl={baseUrl} accessToken={script.accessToken} />
          </section>

          <section>
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-[13px] font-semibold text-zinc-300">源代码</h2>
              <div className="flex items-center gap-2">
                <span className="chip font-mono">
                  {script.code.split("\n").length} 行 · {(new TextEncoder().encode(script.code).length / 1024).toFixed(1)} KB
                </span>
                <span className="chip !border-lime/25 !bg-lime/10 !text-lime-300">🔒 已保护</span>
                <span className="chip !border-brand/30 !bg-brand/10 !text-brand-2">
                  {`${
                    script.obfuscation === "none"
                      ? "未混淆"
                      : script.obfuscation === "light"
                        ? "轻量混淆"
                        : script.obfuscation === "strong"
                          ? "强混淆"
                          : "极限混淆"
                  } · 膨胀 ${script.inflation}/3`}
                </span>
              </div>
            </div>

            {canViewSource ? (
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-[11px] text-zinc-500">
                    {isOwner ? "仅你（作者）可见" : "站长视图（原始源码）"}
                  </span>
                  <div className="ml-auto flex items-center gap-2">
                    <CopyButton value={script.code} label="复制源码" />
                    <a
                      href={`/s/${script.slug}/raw`}
                      className="btn btn-ghost !py-2 !text-[12px]"
                    >
                      源码独立页
                    </a>
                    <Link href={`/s/${script.slug}/edit`} className="btn btn-primary !py-2 !text-[12px]">
                      编辑脚本
                    </Link>
                  </div>
                </div>
                <CodeView code={script.code} maxHeight="34rem" />
              </div>
            ) : (
              <div className="relative overflow-hidden rounded-xl border border-line bg-[#080910]">
                <div className="pointer-events-none select-none p-4 font-mono text-[12px] leading-[1.8] text-zinc-800">
                  <p>-- source hidden by loadbin protection</p>
                  <p>-- 该脚本的源码已加密托管</p>
                  <p>loadstring(game:HttpGet("https://***/api/raw/****?key=****"))()</p>
                  <p>local Players = game:GetService("Players")</p>
                  <p>-- ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓</p>
                  <p>-- ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓</p>
                  <p>-- ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓</p>
                </div>
                <div className="absolute inset-0 grid place-items-center bg-gradient-to-b from-transparent via-[#080910]/85 to-[#080910] px-5 text-center">
                  <div>
                    <span className="mx-auto grid h-10 w-10 place-items-center rounded-xl border border-lime/25 bg-lime/10 text-[16px]">
                      🔒
                    </span>
                    <p className="mt-3 text-[13.5px] font-semibold text-white">源码受保护，禁止直接查看</p>
                    <p className="mx-auto mt-1.5 max-w-sm text-[11.5px] leading-relaxed text-zinc-500">
                      直接访问 raw 链接（复制到浏览器、curl、预览面板）都会被拒绝并返回 403。
                      只有执行器携带签名发起的请求才能读取代码。
                    </p>
                    <div className="mt-3 flex flex-wrap justify-center gap-2">
                      <Link href="/docs#protection" className="btn btn-ghost !py-1.5 !text-[11.5px]">
                        保护机制
                      </Link>
                      <Link href="/new" className="btn btn-ghost !py-1.5 !text-[11.5px]">托管我的脚本</Link>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </section>

          <section>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-[14px] font-semibold text-white">
                评论 <span className="font-mono text-[12px] text-zinc-500">({comments.length})</span>
              </h2>
              <span className="font-mono text-[10.5px] text-zinc-600">需要登录 · 暂不需要</span>
            </div>
            <CommentForm slug={script.slug} />

            <div className="mt-4 space-y-3">
              {comments.map((comment) => (
                <div key={comment.id} className="rounded-xl border border-line bg-panel/40 p-4">
                  <div className="flex items-center gap-2">
                    <span className="grid h-6 w-6 place-items-center rounded-full bg-white/[0.06] font-mono text-[10px] text-zinc-400">
                      {initialOf(comment.authorName)}
                    </span>
                    <span className="text-[12.5px] text-zinc-300">{comment.authorName}</span>
                    <span className="font-mono text-[10.5px] text-zinc-600">{timeAgo(comment.createdAt)}</span>
                  </div>
                  <p className="mt-2 whitespace-pre-wrap text-[13px] leading-relaxed text-zinc-400">
                    {comment.body}
                  </p>
                </div>
              ))}
              {comments.length === 0 && (
                <p className="rounded-xl border border-dashed border-line px-4 py-8 text-center text-[12.5px] text-zinc-600">
                  还没有评论，来说说运行情况吧。
                </p>
              )}
            </div>
          </section>
        </div>

        {/* Sidebar */}
        <aside className="space-y-4 lg:sticky lg:top-24">
          <div className="card p-4">
            <LikeButton slug={script.slug} initialLikes={script.likes} initialLiked={liked} />
            <div className="mt-3 grid grid-cols-3 divide-x divide-line rounded-lg border border-line bg-white/[0.015]">
              {[
                { label: "浏览", value: formatNumber(views) },
                { label: "调用", value: formatNumber(script.runs) },
                { label: "评论", value: formatNumber(comments.length) },
              ].map((item) => (
                <div key={item.label} className="px-2 py-2.5 text-center">
                  <p className="font-mono text-[13px] text-zinc-200">{item.value}</p>
                  <p className="mt-0.5 text-[10px] text-zinc-600">{item.label}</p>
                </div>
              ))}
            </div>
            <div className="mt-3 flex gap-2">
              <CopyButton value={pageUrl} label="分享页面" className="flex-1 !py-2 !text-[11.5px]" />
              <CopyButton
                value={`loadstring(game:HttpGet("${baseUrl}/api/raw/${script.slug}"))()`}
                label="复制执行"
                variant="primary"
                className="flex-1 !py-2 !text-[11.5px]"
              />
            </div>
          </div>

          <div className="card p-4">
            <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-zinc-500">脚本信息</p>
            <dl className="mt-3 space-y-2.5 text-[12px]">
              {[
                { k: "短链", v: script.slug, mono: true },
                { k: "语言", v: script.language, mono: true },
                { k: "可见性", v: script.visibility === "public" ? "公开" : "不公开" },
                { k: "最后更新", v: timeAgo(script.updatedAt) },
                { k: "文件大小", v: `${(new TextEncoder().encode(script.code).length / 1024).toFixed(1)} KB`, mono: true },
              ].map((row) => (
                <div key={row.k} className="flex items-baseline justify-between gap-3">
                  <dt className="shrink-0 text-zinc-500">{row.k}</dt>
                  <dd className={`min-w-0 truncate text-right text-zinc-300 ${row.mono ? "font-mono text-[11.5px]" : ""}`}>
                    {row.v}
                  </dd>
                </div>
              ))}
            </dl>
            <div className="mt-4 rounded-lg border border-line bg-white/[0.015] p-3">
              <p className="text-[11.5px] text-zinc-400">{isOwner ? "你是该脚本的作者" : "你是作者？"}</p>
              <p className="mt-1 text-[11px] leading-relaxed text-zinc-600">
                {isOwner
                  ? "你可以在账号中心修改代码、重置访问签名或删除脚本。"
                  : "登录账号或使用编辑密钥即可修改代码、重置签名或删除脚本。"}
              </p>
              <Link
                href={isOwner ? "/account" : "/login"}
                className="mt-2 inline-flex text-[11.5px] text-brand-2 hover:underline"
              >
                {isOwner ? "打开账号中心 →" : "登录后管理 →"}
              </Link>
              {!isOwner && (
                <Link href="/manage" className="ml-3 mt-2 inline-flex text-[11.5px] text-zinc-500 hover:underline">
                  用密钥管理 →
                </Link>
              )}
            </div>
          </div>

          <div className="rounded-xl border border-line bg-panel/40 p-4">
            <p className="flex items-center gap-1.5 text-[12px] font-medium text-zinc-300">
              <span className="text-lime">◇</span> 安全提示
            </p>
            <p className="mt-1.5 text-[11px] leading-relaxed text-zinc-600">
              执行他人脚本前请自行审查代码。loadbin 只负责存储与分发，不对脚本行为负责。
            </p>
          </div>
        </aside>
      </div>

      {related.length > 0 && (
        <section className="mt-14">
          <div className="flex items-end justify-between gap-4">
            <h2 className="text-[18px] font-semibold tracking-tight text-white">相关脚本</h2>
            <Link href="/scripts" className="text-[12px] text-zinc-500 hover:text-brand-2">查看全部 →</Link>
          </div>
          <div className="mt-4 grid gap-4 md:grid-cols-3">
            {related.map((item) => (
              <ScriptCard key={item.slug} script={item} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
