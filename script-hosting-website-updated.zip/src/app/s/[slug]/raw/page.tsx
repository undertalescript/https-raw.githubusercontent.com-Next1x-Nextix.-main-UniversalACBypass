import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { CodeView } from "@/components/code-view";
import { CopyButton } from "@/components/copy-button";
import { ensureSeeded } from "@/db/seed";
import { getSessionUser, isAdminUser } from "@/lib/auth";
import { formatNumber } from "@/lib/format";
import { getScriptBySlug } from "@/lib/queries";
import { getBaseUrl, loadstringFor, pathUrlFor, rawUrlFor } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "源码（仅作者可见）",
  robots: { index: false, follow: false, noarchive: true },
};

type PageProps = { params: Promise<{ slug: string }> };

export default async function SourcePage({ params }: PageProps) {
  await ensureSeeded();
  const { slug } = await params;
  const script = await getScriptBySlug(slug);
  if (!script) notFound();

  const user = await getSessionUser();
  const isOwner = Boolean(user && script.ownerId === user.id);
  const isAdmin = isAdminUser(user);
  const canView = isOwner || isAdmin;

  if (!canView) {
    return (
      <div className="mx-auto grid min-h-[62vh] max-w-2xl place-items-center px-5 py-14">
        <div className="card w-full p-7 text-center">
          <span className="mx-auto grid h-11 w-11 place-items-center rounded-xl border border-rose-400/30 bg-rose-400/10 text-[18px]">
            🔒
          </span>
          <p className="mt-4 font-mono text-[11px] uppercase tracking-[0.18em] text-rose-300">403 · source protected</p>
          <h1 className="mt-2 text-[20px] font-semibold text-white">源码受保护</h1>
          <p className="mx-auto mt-2 max-w-md text-[12.5px] leading-relaxed text-zinc-500">
            「{script.title}」的源码仅作者本人可以查看。直接访问 raw 链接、拷贝到浏览器或使用其他工具都会被拒绝。
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            <Link href={`/s/${script.slug}`} className="btn btn-primary">返回脚本页面</Link>
            <Link href="/docs#protection" className="btn btn-ghost">保护机制</Link>
          </div>
        </div>
      </div>
    );
  }

  const baseUrl = await getBaseUrl();
  const rawUrl = rawUrlFor(baseUrl, script.slug, script.accessToken);
  const pathUrl = pathUrlFor(baseUrl, script.slug, script.accessToken);
  const loader = loadstringFor(baseUrl, script.slug, script.accessToken);

  return (
    <div className="mx-auto max-w-6xl px-5 py-10">
      <nav className="flex flex-wrap items-center gap-1.5 font-mono text-[11px] text-zinc-600">
        <Link href="/account" className="hover:text-zinc-300">account</Link>
        <span>/</span>
        <Link href={`/s/${script.slug}`} className="hover:text-zinc-300">{script.slug}</Link>
        <span>/</span>
        <span className="text-zinc-400">source</span>
      </nav>

      <div className="mt-4 flex flex-wrap items-end justify-between gap-4">
        <div className="min-w-0">
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-lime-300">
            🔒 {isOwner ? "owner only" : "site owner view"}
          </p>
          <h1 className="mt-2 truncate text-[26px] font-semibold tracking-tight text-white">{script.title}</h1>
          <p className="mt-2 break-all font-mono text-[11.5px] text-zinc-500">
            /api/raw/{script.slug}?key=•••• · {script.code.split("\n").length} 行 · 执行{" "}
            {formatNumber(script.runs)} 次
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <CopyButton value={script.code} label="复制源码" variant="primary" />
          <Link href={`/s/${script.slug}/edit`} className="btn btn-ghost">编辑脚本</Link>
          <Link href={`/s/${script.slug}`} className="btn btn-ghost">公开页面</Link>
        </div>
      </div>

      <div className="mt-6 flex items-center gap-2 rounded-xl border border-amber-400/20 bg-amber-400/[0.05] px-4 py-2.5">
        <span className="text-[12px] text-amber-300">🔐</span>
        <p className="text-[11.5px] leading-relaxed text-zinc-400">
          这是作者专属视图。请不要把源码或带签名的直链公开分享；如已外泄，可在账号中心「重置签名」。
        </p>
      </div>

      <div className="mt-4">
        <CodeView code={script.code} maxHeight="none" wrap />
      </div>

      <div className="card mt-5 p-4">
        <p className="text-[12.5px] font-medium text-zinc-300">执行方式（含签名）</p>
        <div className="mt-2 flex flex-col gap-2 rounded-lg border border-line bg-[#080910] p-3 sm:flex-row sm:items-center">
          <code className="min-w-0 flex-1 overflow-x-auto whitespace-pre font-mono text-[12px] text-lime-300">
            {loader}
          </code>
          <CopyButton value={loader} label="复制" className="!py-1.5 !text-[11px]" />
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <code className="min-w-0 flex-1 truncate font-mono text-[11px] text-zinc-500">{rawUrl}</code>
          <CopyButton value={rawUrl} label="复制签名直链" className="!py-1.5 !text-[11px]" />
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <code className="min-w-0 flex-1 truncate font-mono text-[11px] text-zinc-500">{pathUrl}</code>
          <CopyButton value={pathUrl} label="复制路径直链" className="!py-1.5 !text-[11px]" />
        </div>
      </div>
    </div>
  );
}
