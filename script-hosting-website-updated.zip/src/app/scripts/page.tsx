import Link from "next/link";
import type { Metadata } from "next";
import { ScriptCard } from "@/components/script-card";
import { ensureSeeded } from "@/db/seed";
import { cn } from "@/lib/format";
import { getTagCloud, listScripts, normalizePage, normalizeSort, type SortKey } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "脚本库",
  description: "浏览社区托管的 Luau / Roblox 脚本，按标签、热度与更新时间筛选。",
};

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

const SORTS: { key: SortKey; label: string }[] = [
  { key: "trending", label: "综合热度" },
  { key: "popular", label: "浏览最多" },
  { key: "newest", label: "最新更新" },
];

function firstValue(value: string | string[] | undefined): string {
  if (Array.isArray(value)) return value[0] ?? "";
  return value ?? "";
}

function queryString(params: Record<string, string | undefined>): string {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value) search.set(key, value);
  }
  const result = search.toString();
  return result ? `?${result}` : "";
}

export default async function ScriptsPage({ searchParams }: { searchParams: SearchParams }) {
  await ensureSeeded();

  const resolved = await searchParams;
  const q = firstValue(resolved.q).slice(0, 80);
  const tag = firstValue(resolved.tag).slice(0, 30);
  const sort = normalizeSort(firstValue(resolved.sort));
  const page = normalizePage(firstValue(resolved.page));

  const [result, tags] = await Promise.all([
    listScripts({ q, tag, sort, page, perPage: 9 }),
    getTagCloud(14),
  ]);

  const baseParams = { q: q || undefined, tag: tag || undefined, sort: sort === "trending" ? undefined : sort };

  return (
    <div className="mx-auto max-w-6xl px-5 py-12">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-2">/ library</p>
          <h1 className="mt-2 text-[30px] font-semibold tracking-tight text-white">脚本库</h1>
          <p className="mt-2 max-w-xl text-[13.5px] leading-relaxed text-zinc-500">
            共 <span className="font-mono text-zinc-300">{result.total}</span> 个公开脚本。每个脚本都提供可直接执行的
            loadstring 原始链接。
          </p>
        </div>
        <Link href="/new" className="btn btn-primary">
          <span className="text-base leading-none">+</span> 上传脚本
        </Link>
      </div>

      {/* Search */}
      <form action="/scripts" className="card mt-7 flex flex-col gap-3 p-3.5 sm:flex-row sm:items-center">
        <div className="flex flex-1 items-center gap-2 rounded-lg border border-line bg-[#080910] px-3">
          <span className="text-zinc-600">⌕</span>
          <input
            type="search"
            name="q"
            defaultValue={q}
            placeholder="搜索脚本标题、简介或游戏名…"
            className="w-full bg-transparent py-2.5 text-[13px] text-zinc-200 outline-none placeholder:text-zinc-600"
          />
        </div>
        {tag && <input type="hidden" name="tag" value={tag} />}
        {sort !== "trending" && <input type="hidden" name="sort" value={sort} />}
        <button type="submit" className="btn btn-primary">搜索</button>
        {(q || tag) && (
          <Link href="/scripts" className="btn btn-ghost">清除筛选</Link>
        )}
      </form>

      {/* Filters */}
      <div className="mt-5 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-1.5">
          <Link href={`/scripts${queryString({ q: q || undefined, sort: sort === "trending" ? undefined : sort })}`} className={cn("chip", !tag && "chip-active")}>
            全部
          </Link>
          {tags.map((item) => (
            <Link
              key={item.name}
              href={`/scripts${queryString({ q: q || undefined, tag: item.name, sort: sort === "trending" ? undefined : sort })}`}
              className={cn("chip", tag === item.name && "chip-active")}
            >
              {item.name}
              <span className="font-mono text-[10px] opacity-60">{item.count}</span>
            </Link>
          ))}
        </div>
        <div className="flex items-center gap-1 rounded-lg border border-line bg-panel/60 p-1">
          {SORTS.map((option) => (
            <Link
              key={option.key}
              href={`/scripts${queryString({ q: q || undefined, tag: tag || undefined, sort: option.key === "trending" ? undefined : option.key })}`}
              className={cn(
                "rounded-md px-2.5 py-1.5 text-[11.5px] transition-colors",
                sort === option.key ? "bg-brand/15 text-brand-2" : "text-zinc-500 hover:text-zinc-200",
              )}
            >
              {option.label}
            </Link>
          ))}
        </div>
      </div>

      {/* Results */}
      {result.items.length > 0 ? (
        <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {result.items.map((script) => (
            <ScriptCard key={script.slug} script={script} />
          ))}
        </div>
      ) : (
        <div className="card mt-6 grid place-items-center px-6 py-20 text-center">
          <div className="grid h-12 w-12 place-items-center rounded-xl border border-line bg-white/[0.03] text-xl text-zinc-500">
            ⌕
          </div>
          <h2 className="mt-4 text-[15px] font-semibold text-white">没有找到匹配的脚本</h2>
          <p className="mt-2 max-w-sm text-[12.5px] leading-relaxed text-zinc-500">
            换个关键词，或者清除筛选条件看看全部脚本。也可以直接上传你需要的脚本。
          </p>
          <div className="mt-5 flex gap-2">
            <Link href="/scripts" className="btn btn-ghost">查看全部</Link>
            <Link href="/new" className="btn btn-primary">上传脚本</Link>
          </div>
        </div>
      )}

      {/* Pagination */}
      {result.totalPages > 1 && (
        <div className="mt-8 flex items-center justify-center gap-2">
          {page > 1 && (
            <Link
              href={`/scripts${queryString({ ...baseParams, page: String(page - 1) })}`}
              className="btn btn-ghost !py-2"
            >
              ← 上一页
            </Link>
          )}
          <span className="px-3 font-mono text-[12px] text-zinc-500">
            {result.page} / {result.totalPages}
          </span>
          {page < result.totalPages && (
            <Link
              href={`/scripts${queryString({ ...baseParams, page: String(page + 1) })}`}
              className="btn btn-ghost !py-2"
            >
              下一页 →
            </Link>
          )}
        </div>
      )}
    </div>
  );
}
