import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/auth-form";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "注册",
  description: "免费注册 loadbin，托管 Luau 脚本并保护源码。",
};

export default async function RegisterPage() {
  const user = await getSessionUser();
  if (user) redirect("/account");

  return (
    <div className="mx-auto flex max-w-6xl flex-col items-center px-5 py-14">
      <AuthForm mode="register" />
      <p className="mt-5 max-w-sm text-center text-[11.5px] leading-relaxed text-zinc-600">
        注册即表示你同意仅上传自己拥有分发权的代码。我们只保存用户名与哈希后的密码。
      </p>
    </div>
  );
}
