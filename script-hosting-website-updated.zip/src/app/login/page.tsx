import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/auth-form";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "登录",
  description: "登录 loadbin 管理你的脚本与源码保护设置。",
};

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const user = await getSessionUser();
  if (user) redirect("/account");

  const query = await searchParams;
  const rawNext = Array.isArray(query.next) ? query.next[0] : query.next;
  const next = rawNext && rawNext.startsWith("/") ? rawNext : undefined;

  return (
    <div className="mx-auto flex max-w-6xl flex-col items-center px-5 py-14">
      <AuthForm mode="login" next={next} />
      <p className="mt-5 max-w-sm text-center text-[11.5px] leading-relaxed text-zinc-600">
        登录后上传的脚本会绑定到你的账号，源码默认开启保护：直接访问 raw 链接会被拒绝。
      </p>
    </div>
  );
}
