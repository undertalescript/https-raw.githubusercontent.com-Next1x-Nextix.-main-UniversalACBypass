import Link from "next/link";
import type { Metadata } from "next";
import { CodeView } from "@/components/code-view";
import { CopyButton } from "@/components/copy-button";
import { getBaseUrl } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "API 文档",
  description: "loadbin 开放接口：上传、读取原始脚本、更新、删除、点赞与评论。",
};

const SECTIONS = [
  { id: "quickstart", label: "快速开始" },
  { id: "protection", label: "源码保护（重点）" },
  { id: "obfuscation", label: "Shield v3 混淆" },
  { id: "raw", label: "读取原始脚本" },
  { id: "list", label: "脚本列表" },
  { id: "detail", label: "脚本详情" },
  { id: "create", label: "创建脚本" },
  { id: "update", label: "更新 / 删除" },
  { id: "like", label: "点赞" },
  { id: "comments", label: "评论" },
  { id: "auth", label: "注册 / 登录" },
  { id: "owner", label: "站长控制台" },
  { id: "troubleshoot", label: "常见问题" },
  { id: "errors", label: "状态码" },
];

export default async function DocsPage() {
  const baseUrl = await getBaseUrl();

  return (
    <div className="mx-auto max-w-6xl px-5 py-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-2">/ api reference</p>
          <h1 className="mt-2 text-[30px] font-semibold tracking-tight text-white">API 文档</h1>
          <p className="mt-2 max-w-2xl text-[13.5px] leading-relaxed text-zinc-500">
            loadbin 的所有功能都构建在公开 HTTP 接口上。返回 JSON，无需额外认证；写操作需要创建脚本时得到的编辑密钥。
          </p>
        </div>
        <div className="rounded-xl border border-line bg-panel/60 px-3.5 py-2.5 font-mono text-[11.5px] text-zinc-400">
          base · <span className="text-brand-2">{baseUrl}</span>
        </div>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[200px_1fr]">
        <aside className="hidden lg:block">
          <div className="sticky top-24 space-y-1">
            <p className="mb-2 px-2 font-mono text-[10px] uppercase tracking-[0.16em] text-zinc-600">endpoints</p>
            {SECTIONS.map((section) => (
              <a
                key={section.id}
                href={`#${section.id}`}
                className="block rounded-lg px-2 py-1.5 text-[12.5px] text-zinc-500 transition-colors hover:bg-white/[0.04] hover:text-zinc-200"
              >
                {section.label}
              </a>
            ))}
          </div>
        </aside>

        <div className="min-w-0 space-y-6">
          <section id="quickstart" className="card scroll-mt-24 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip !border-lime/30 !bg-lime/10 !text-lime-300">GET</span>
              <code className="font-mono text-[13px] text-zinc-200">/api/raw/:slug</code>
            </div>
            <h2 className="mt-3 text-[17px] font-semibold text-white">快速开始</h2>
            <p className="mt-2 text-[13px] leading-relaxed text-zinc-400">
              每份脚本都有一条<strong className="text-zinc-200">带签名的原始地址</strong>，
              直接配合 <code className="font-mono text-lime-300">loadstring</code> 即可执行。
              接口会校验签名、拒绝浏览器 / curl / 爬虫访问，只把源码交给执行器。
            </p>
            <div className="mt-4">
              <CodeView
                code={`-- 从脚本页复制完整片段（含每个脚本独有的 key）\nloadstring(game:HttpGet("${baseUrl}/api/raw/<slug>?key=<token>"))()\n\n-- 带错误处理\nlocal source = game:HttpGet("${baseUrl}/api/raw/<slug>?key=<token>")\nlocal chunk, err = loadstring(source)\n\nif not chunk then\n    return warn("[loadbin] " .. tostring(err))\nend\n\nchunk()`}
                maxHeight="18rem"
              />
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <span className="text-[11.5px] text-zinc-500">你也可以直接用浏览器打开原始地址确认内容。</span>
              <Link href="/scripts" className="text-[11.5px] text-brand-2 hover:underline">先找一个脚本 →</Link>
            </div>
          </section>

          <section id="protection" className="card scroll-mt-24 border-lime/25 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip !border-lime/30 !bg-lime/10 !text-lime-300">🔒 SOURCE PROTECTION</span>
              <h2 className="text-[17px] font-semibold text-white">源码保护机制</h2>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-zinc-400">
              默认情况下每份脚本的源码都是<strong className="text-zinc-200">不可直接读取</strong>的。
              复制 raw 链接粘贴到浏览器、curl、Postman、预览面板或任何爬虫，都会得到{" "}
              <code className="font-mono text-rose-300">403</code>，响应体是一张保护提示页，绝不会包含代码。
            </p>
            <div className="mt-4 grid gap-2 sm:grid-cols-2">
              {[
                { t: "① 每个脚本独立签名", d: "raw 地址必须带 ?key=<accessToken>，缺失或错误直接 403。" },
                { t: "② 非执行器一律拒绝", d: "浏览器 UA、Sec-Fetch-Mode: navigate、Accept: text/html 全部拦截。" },
                { t: "③ 源码不出现在页面", d: "详情页只显示打码占位，源码仅作者（登录后）可见。" },
                { t: "④ 签名可随时重置", d: "疑似泄露时在账号中心重置签名，旧链接立即失效。" },
              ].map((item) => (
                <div key={item.t} className="rounded-lg border border-line bg-white/[0.015] px-3 py-2.5">
                  <p className="text-[12px] font-medium text-zinc-200">{item.t}</p>
                  <p className="mt-1 text-[11.5px] leading-relaxed text-zinc-500">{item.d}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-rose-500/25 bg-rose-500/[0.05] p-3">
                <p className="font-mono text-[10px] uppercase tracking-wider text-rose-300">被拒绝（浏览器复制链接）</p>
                <pre className="mt-2 overflow-x-auto font-mono text-[11px] leading-relaxed text-zinc-400">
                  <code>{`GET /api/raw/orbit-esp-9f3k
HTTP/1.1 403 Forbidden
Content-Type: text/html
<保护提示页，无任何源码>`}</code>
                </pre>
              </div>
              <div className="rounded-xl border border-lime/25 bg-lime/[0.05] p-3">
                <p className="font-mono text-[10px] uppercase tracking-wider text-lime-300">被允许（执行器 + 签名）</p>
                <pre className="mt-2 overflow-x-auto font-mono text-[11px] leading-relaxed text-zinc-400">
                  <code>{`GET /api/raw/orbit-esp-9f3k?key=8f2c…
User-Agent: Roblox/WinInet
Accept: */*
HTTP/1.1 200 OK
<脚本源码>`}</code>
                </pre>
              </div>
            </div>
            <p className="mt-3 rounded-lg border border-line bg-white/[0.015] px-3 py-2 text-[11.5px] leading-relaxed text-zinc-500">
              签名会写在 loadstring 片段里，所以拿到片段的人可以让脚本运行 —— 但无法通过浏览器查看或转存源码。
              如果需要彻底不暴露代码执行，请在发布前自行混淆 / 加密脚本。
            </p>
          </section>

          <section id="obfuscation" className="card scroll-mt-24 border-brand/25 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip !border-brand/40 !bg-brand/15 !text-brand-2">🛡 OBFUSCATION</span>
              <h2 className="text-[17px] font-semibold text-white">Shield v3 混淆与动态膨胀</h2>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-zinc-400">
              raw 接口不再直接返回可读源码。服务端会把代码加密成不可读的加载器（默认<b className="text-zinc-200">极限混淆</b>），
              执行器 loadstring 后由加载器在运行时还原并执行；<b className="text-zinc-200">作者在后台仍看到原始源码</b>。
            </p>
            <div className="mt-4 grid gap-2 sm:grid-cols-3">
              {[
                { t: "极限 · Shield v3（默认）", d: "两段式：raw 只返回引导器（不含载荷），加密载荷在运行时从 /api/stage 限时签名取回；静态文件里无任何可解内容。" },
                { t: "强", d: "同样的状态机 VM 与字符串加密，无诱饵块，体积略小。" },
                { t: "动态膨胀 0-3", d: "运行时生成填充表并参与解密；等级越高诱饵函数与填充表越大。0 关闭，2 推荐，3 最强。" },
                { t: "轻量混淆", d: "单层编码，体积约为源码 2 倍，加载更快，适合大脚本。" },
                { t: "不混淆", d: "原样返回（仅建议作者自用或开源脚本）。" },
              ].map((item) => (
                <div key={item.t} className="rounded-lg border border-line bg-white/[0.015] px-3 py-2.5">
                  <p className="text-[12px] font-medium text-zinc-200">{item.t}</p>
                  <p className="mt-1 text-[11.5px] leading-relaxed text-zinc-500">{item.d}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-rose-500/25 bg-rose-500/[0.05] p-3">
                <p className="font-mono text-[10px] uppercase tracking-wider text-rose-300">抓到的内容（强混淆）</p>
                <pre className="mt-2 overflow-x-auto font-mono text-[11px] leading-relaxed text-zinc-400">
                  <code>{`-- Protected by loadbin Shield v3
return(function(_KNTNa,_STO,...) local _ybG67rAT=(_KNTNa*35+_STO)%9879
local _vroHhzIx,_wqG7,_AQw1u_=string.byte,string.sub,string.char   -- 随机化别名
local _tSdpbdU={ {231,88,…}, {12,9,…}, … }   -- 加密字符串表（含诱饵）
local _9eNo={0,0,0,0,0} local _u2RI0={}      -- VM 寄存器 / 输出缓冲
local _mMXNvUp7Wkt=655432                     -- 状态机状态
while _mMXNvUp7Wkt do
  local _EUFlqhnrz=_Vjo6cu84G(_mMXNvUp7Wkt*48758+341486,2147483629)
  if _EUFlqhnrz==770303600 then …             -- 分派到某个 VM 步骤
  elseif _EUFlqhnrz==1649571792 then …
  end
end
end)(104,890,...)`}</code>
                </pre>
              </div>
              <div className="rounded-xl border border-line bg-white/[0.015] p-3">
                <p className="font-mono text-[10px] uppercase tracking-wider text-zinc-500">说明与限制</p>
                <ul className="mt-2 space-y-1 text-[11.5px] leading-relaxed text-zinc-500">
                  <li>· 不使用 base64 / hex / 明文字符串：密文是打包后的整数，常规静态工具无法直接提取。</li>
                  <li>· 动态膨胀：填充表在运行时重新计算并参与第二层掩码，诱饵函数与不透明分支随等级增加。</li>
                  <li>· 每次请求都换密钥与操作码，转发或缓存得到的版本各不相同。</li>
                  <li>· 客户端脚本理论上仍可被运行时 dump，混淆的目标是让抓取到的内容不可读、不可直接复用。</li>
                  <li>· 修改混淆强度：上传时选择，或作者在编辑页随时切换。</li>
                  <li>· <code className="font-mono">?plain=1</code> 仍需签名，仅用于作者自测。</li>
                </ul>
              </div>
            </div>
          </section>

          <section id="raw" className="card scroll-mt-24 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip !border-lime/30 !bg-lime/10 !text-lime-300">GET</span>
              <code className="font-mono text-[13px] text-zinc-200">/api/raw/:slug?key=:token</code>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-zinc-400">
              返回脚本的<b className="text-zinc-200">混淆构建</b>（默认强混淆）。为了让执行器不抛出 <code className="font-mono">HTTP 403</code>，
              非浏览器请求遇到「缺少签名 / 签名错误 / 脚本停用 / 站长关闭执行 / 脚本不存在」时会返回{" "}
              <b className="text-zinc-200">HTTP 200 + 一行 Lua <code className="font-mono">warn(&quot;[loadbin] …&quot;)</code></b>，
              在控制台直接显示中文原因；浏览器直接打开则始终是 403 保护页。每次成功读取会让调用计数 +1。
            </p>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {[
                { path: "/api/raw/:slug?key=", note: "主接口" },
                { path: "/raw/:slug?key=", note: "备用别名（内容一致）" },
                { path: "/k/:key/:slug", note: "签名放在路径里，兼容会吞查询串的执行器" },
                { path: "/l/:slug?key=", note: "最短别名" },
                { path: "/api/stage/:slug", note: "第二段载荷（执行器运行时取，限时签名）" },
              ].map((item) => (
                <div key={item.path} className="rounded-lg border border-line bg-white/[0.015] px-3 py-2">
                  <code className="block font-mono text-[11.5px] text-brand-2">{item.path}</code>
                  <span className="text-[11px] text-zinc-500">{item.note}</span>
                </div>
              ))}
            </div>
            <div className="mt-3">
              <CodeView
                code={`# 执行器内部实际发出的请求（示例）\nGET /api/raw/orbit-esp-9f3k?key=8f2c9a...\nUser-Agent: Roblox/WinInet\n\n# 直接复制到终端会得到 403\ncurl "https://<host>/api/raw/orbit-esp-9f3k?key=8f2c9a..."`}
                showLineNumbers={false}
                maxHeight="12rem"
              />
            </div>
          </section>

          <section id="list" className="card scroll-mt-24 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip !border-lime/30 !bg-lime/10 !text-lime-300">GET</span>
              <code className="font-mono text-[13px] text-zinc-200">/api/scripts</code>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-zinc-400">列出公开脚本，支持搜索、标签与排序。</p>
            <div className="mt-4 overflow-hidden rounded-lg border border-line">
              <table className="w-full text-left text-[12px]">
                <thead className="bg-white/[0.03] font-mono text-[10.5px] uppercase tracking-wider text-zinc-500">
                  <tr>
                    <th className="px-3 py-2">参数</th>
                    <th className="px-3 py-2">类型</th>
                    <th className="px-3 py-2">说明</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line/70 text-zinc-400">
                  {[
                    ["q", "string", "模糊匹配标题与简介"],
                    ["tag", "string", "按标签过滤，如 自动"],
                    ["sort", "enum", "trending | popular | newest"],
                    ["page", "number", "页码，默认 1"],
                    ["perPage", "number", "每页数量，1-30，默认 12"],
                  ].map(([key, type, desc]) => (
                    <tr key={key}>
                      <td className="px-3 py-2 font-mono text-zinc-200">{key}</td>
                      <td className="px-3 py-2 font-mono text-[11px] text-zinc-500">{type}</td>
                      <td className="px-3 py-2">{desc}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-3">
              <CodeView
                code={`curl "${baseUrl}/api/scripts?tag=自动&sort=popular&perPage=3"`}
                showLineNumbers={false}
                maxHeight="6rem"
              />
            </div>
          </section>

          <section id="detail" className="card scroll-mt-24 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip !border-lime/30 !bg-lime/10 !text-lime-300">GET</span>
              <code className="font-mono text-[13px] text-zinc-200">/api/scripts/:slug</code>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-zinc-400">
              返回脚本元数据与完整源码。附加 <code className="font-mono">?key=EDIT_KEY</code>（或请求头{" "}
              <code className="font-mono">x-edit-key</code>）时会额外返回 <code className="font-mono">canEdit</code>{" "}
              字段，用于校验密钥是否正确。
            </p>
            <div className="mt-3">
              <CodeView
                code={`{
  "ok": true,
  "canEdit": true,
  "script": {
    "slug": "orbit-esp-9f3k",
    "title": "Orbit ESP · 通用透视引擎",
    "views": 48213,
    "runs": 92144,
    "likes": 1862,
    "tags": ["透视", "通用", "战斗"]
  }
}`}
                maxHeight="18rem"
              />
            </div>
          </section>

          <section id="create" className="card scroll-mt-24 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip !border-brand/40 !bg-brand/15 !text-brand-2">POST</span>
              <code className="font-mono text-[13px] text-zinc-200">/api/scripts</code>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-zinc-400">
              创建脚本。响应中的 <code className="font-mono text-amber-300">editKey</code> 只返回一次，请立即保存。
            </p>
            <div className="mt-3">
              <CodeView
                code={`curl -X POST "${baseUrl}/api/scripts" \\
  -H "content-type: application/json" \\
  -d '{
    "title": "我的脚本",
    "description": "一句话介绍",
    "code": "print(\\"hello\\")",
    "tags": ["工具"],
    "authorName": "your-name",
    "visibility": "public",
    "slug": "my-script"
  }'`}
                showLineNumbers={false}
                maxHeight="20rem"
              />
            </div>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {[
                ["title", "3-120 字符，必填"],
                ["code", "至少 10 字符，最大 300KB"],
                ["tags", "最多 6 个，每个 ≤20 字符"],
                ["slug", "可选，小写字母 / 数字 / 连字符"],
                ["visibility", "public 或 unlisted"],
                ["authorName", "可选，默认「匿名」"],
              ].map(([key, hint]) => (
                <div key={key} className="flex items-baseline gap-2 rounded-lg border border-line bg-white/[0.015] px-3 py-2">
                  <code className="font-mono text-[11.5px] text-brand-2">{key}</code>
                  <span className="text-[11.5px] text-zinc-500">{hint}</span>
                </div>
              ))}
            </div>
          </section>

          <section id="update" className="card scroll-mt-24 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip !border-amber-400/30 !bg-amber-400/10 !text-amber-300">PATCH</span>
              <code className="font-mono text-[13px] text-zinc-200">/api/scripts/:slug</code>
              <span className="chip !border-rose-500/30 !bg-rose-500/10 !text-rose-300">DELETE</span>
              <code className="font-mono text-[13px] text-zinc-200">/api/scripts/:slug</code>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-zinc-400">
              写操作需要在请求头携带 <code className="font-mono">x-edit-key</code>。更新时短链保持不变，
              修改后的代码对下一次 loadstring 调用立即生效。
            </p>
            <div className="mt-3">
              <CodeView
                code={`# 更新代码\ncurl -X PATCH "${baseUrl}/api/scripts/your-slug" \\\n  -H "x-edit-key: YOUR_EDIT_KEY" \\\n  -H "content-type: application/json" \\\n  -d '{"code": "print(\\"v2\\")" }'\n\n# 删除脚本\ncurl -X DELETE "${baseUrl}/api/scripts/your-slug" \\\n  -H "x-edit-key: YOUR_EDIT_KEY"`}
                showLineNumbers={false}
                maxHeight="20rem"
              />
            </div>
          </section>

          <section id="like" className="card scroll-mt-24 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip !border-brand/40 !bg-brand/15 !text-brand-2">POST</span>
              <code className="font-mono text-[13px] text-zinc-200">/api/scripts/:slug/like</code>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-zinc-400">
              收藏 / 取消收藏。同一访客（IP + UA 哈希）重复点赞不会重复计数。
            </p>
            <div className="mt-3">
              <CodeView
                code={`curl -X POST "${baseUrl}/api/scripts/your-slug/like" \\\n  -H "content-type: application/json" \\\n  -d '{"action":"like"}'   # 或 "unlike"`}
                showLineNumbers={false}
                maxHeight="8rem"
              />
            </div>
          </section>

          <section id="comments" className="card scroll-mt-24 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip !border-lime/30 !bg-lime/10 !text-lime-300">GET</span>
              <span className="chip !border-brand/40 !bg-brand/15 !text-brand-2">POST</span>
              <code className="font-mono text-[13px] text-zinc-200">/api/scripts/:slug/comments</code>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-zinc-400">
              读取或发布评论。评论长度为 2-500 字符，按时间倒序返回最近 30 条。
            </p>
            <div className="mt-3">
              <CodeView
                code={`curl -X POST "${baseUrl}/api/scripts/your-slug/comments" \\\n  -H "content-type: application/json" \\\n  -d '{"authorName":"kiwi","body":"在你的执行器里可以正常运行。"}'`}
                showLineNumbers={false}
                maxHeight="8rem"
              />
            </div>
          </section>

          <section id="auth" className="card scroll-mt-24 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip !border-brand/40 !bg-brand/15 !text-brand-2">AUTH</span>
              <h2 className="text-[17px] font-semibold text-white">注册 / 登录</h2>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-zinc-400">
              注册登录后上传的脚本会绑定账号，并可在账号中心查看源码、重置访问签名。
              会话保存在 HttpOnly Cookie <code className="font-mono">lb_session</code> 中，密码使用 scrypt 加盐哈希。
            </p>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {[
                ["POST /api/auth/register", '{ "username": "kiwi", "password": "••••••" }'],
                ["POST /api/auth/login", '{ "username": "kiwi", "password": "••••••" }'],
                ["POST /api/auth/logout", '无参数，清除会话 Cookie'],
                ["GET /api/auth/me", "返回当前登录用户（未登录时 authenticated=false）"],
              ].map(([endpoint, note]) => (
                <div key={endpoint} className="rounded-lg border border-line bg-white/[0.015] px-3 py-2">
                  <code className="block font-mono text-[11px] text-brand-2">{endpoint}</code>
                  <span className="text-[11px] text-zinc-500">{note}</span>
                </div>
              ))}
            </div>
            <div className="mt-3">
              <CodeView
                code={`curl -c cookies.txt -X POST "${baseUrl}/api/auth/login" \\\n  -H "content-type: application/json" \\\n  -d '{"username":"kiwi","password":"secret123"}'\n\n# 用会话上传脚本（自动归属该账号）\ncurl -b cookies.txt -X POST "${baseUrl}/api/scripts" \\\n  -H "content-type: application/json" \\\n  -d '{"title":"我的脚本","code":"print(\"hi\")"}'`}
                showLineNumbers={false}
                maxHeight="16rem"
              />
            </div>
          </section>

          <section id="owner" className="card scroll-mt-24 border-rose-500/25 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip !border-rose-500/30 !bg-rose-500/10 !text-rose-300">👑 OWNER</span>
              <h2 className="text-[17px] font-semibold text-white">站长控制台</h2>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-zinc-400">
              站长账号（<code className="font-mono">role = admin</code>）登录后，控制台<b className="text-zinc-200">直接显示在账户页</b>{" "}
              <Link href="/account#owner" className="text-brand-2 hover:underline">/account#owner</Link>（旧地址{" "}
              <Link href="/admin" className="text-brand-2 hover:underline">/admin</Link> 会自动跳转），拥有以下权力：
            </p>
            <div className="mt-3 space-y-2">
              {[
                ["全站脚本执行开关", "关闭后所有 raw 请求统一返回 503 + Lua warn，任何人（包括作者）都无法执行脚本，调用计数冻结。"],
                ["停用单个脚本", "无需删除即可让某个脚本无法执行（403），作者仍保留自己的源码。"],
                ["维护模式", "除登录与后台外全站显示维护页，脚本执行可单独保持运行。"],
                ["全站公告", "顶部横幅广播，可配合开关说明原因。"],
                ["删除脚本", "站长可删除任意脚本，链接立即失效。"],
              ].map(([title, desc]) => (
                <div key={title} className="rounded-lg border border-line bg-white/[0.015] px-3 py-2.5">
                  <p className="text-[12px] font-medium text-zinc-200">{title}</p>
                  <p className="mt-0.5 text-[11.5px] leading-relaxed text-zinc-500">{desc}</p>
                </div>
              ))}
            </div>
            <div className="mt-3 rounded-lg border border-line bg-[#080910] px-3 py-2.5">
              <p className="font-mono text-[10px] uppercase tracking-wider text-zinc-500">接口（仅站长）</p>
              <pre className="mt-1.5 overflow-x-auto font-mono text-[11px] leading-relaxed text-zinc-400">
                <code>{`PATCH /api/admin/settings          { scriptsEnabled:false }
PATCH /api/admin/settings          { maintenanceMode:true, announcement:"…" }
PATCH /api/admin/scripts/:slug     { disabled:true }
DELETE /api/admin/scripts/:slug`}</code>
              </pre>
            </div>
            <p className="mt-3 text-[11.5px] leading-relaxed text-zinc-600">
              站长账号由环境变量 <code className="font-mono">ADMIN_USERNAME</code> /{" "}
              <code className="font-mono">ADMIN_PASSWORD</code> 决定；未设置时使用预置账号，并在启动时自动提升为 admin。
            </p>
          </section>

          <section id="troubleshoot" className="card scroll-mt-24 p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip !border-amber-400/30 !bg-amber-400/10 !text-amber-300">HELP</span>
              <h2 className="text-[17px] font-semibold text-white">常见问题</h2>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-zinc-400">
              <strong className="text-zinc-200">浏览器打开直链被拒绝是正常行为</strong>，说明源码保护生效了。
              下面是执行器侧可能遇到的问题与处理方法：
            </p>

            <div className="mt-4 space-y-3">
              {[
                {
                  title: "1. 浏览器 / curl 打开直链 → 403",
                  body: "这是设计如此：源码保护会拒绝一切非执行器请求，响应体只有保护提示页。要执行脚本请使用详情页复制的完整 loadstring（内含签名）。",
                  code: `-- ✅ 正确用法\nloadstring(game:HttpGet("<host>/api/raw/<slug>?key=<token>"))()`,
                },
                {
                  title: "2. 执行器提示 staged link expired",
                  body: "第二段载荷的有效期是 15 分钟。请回到脚本页面重新复制 loadstring 再执行；长期使用的脚本建议通过你自建的反代保持同一 loadstring 片段（签名与短链不变，片段本身不过期）。",
                  code: `-- 片段里带 n=<nonce>，过期后需重新复制一次`,
                },
                {
                  title: "3. 执行器报 HTTP 403 / 签名无效",
                  body: "这是浏览器或缺少签名时的保护响应。请复制脚本页「稳定版（推荐）」整段代码。执行器若吞掉查询串，改用路径直链 /k/:key/:slug。作者重置签名也会让旧片段失效。",
                  code: `-- ✅ 完整片段（key 在查询串）\nloadstring(game:HttpGet("<host>/api/raw/<slug>?key=<token>"))()\n\n-- ✅ 路径直链（兼容吞查询串的执行器）\nloadstring(game:HttpGet("<host>/k/<token>/<slug>"))()`,
                },
                {
                  title: "4. 控制台显示中文 warn 而不是报错",
                  body: "这种情况是保护逻辑主动返回的提示（HTTP 200），脚本本身没有执行。按提示修正签名即可；站长关闭执行时也会出现同类提示。",
                  code: `[loadbin] 缺少访问签名 ?key=…, 请复制完整 loadstring`,
                },
                {
                  title: "5. 域名被网络 / 执行器拦截",
                  body: "预览环境的 *.e2b.app 域名可能被屏蔽。可在 /raw/:slug?key=... 备用路径重试，或把自己的域名反代到同一接口（记得保留查询参数 key）。",
                  code: `/raw/<slug>?key=<token>`,
                },
                {
                  title: "6. 执行器没开 HttpGet / 需要 UA",
                  body: "部分执行器默认关闭 HttpGet。可改用 request 版本并带上常见 User-Agent；签名参数保持不变。",
                  code: `local res = request({ Url = RAW, Method = "GET",\n  Headers = { ["User-Agent"] = "Roblox/WinInet" } })\nloadstring(res.Body)()`,
                },
              ].map((item) => (
                <div key={item.title} className="rounded-xl border border-line bg-white/[0.015] p-4">
                  <p className="text-[13px] font-medium text-zinc-200">{item.title}</p>
                  <p className="mt-1.5 text-[12.5px] leading-relaxed text-zinc-500">{item.body}</p>
                  <pre className="mt-2.5 overflow-x-auto rounded-lg border border-line bg-[#080910] px-3 py-2 font-mono text-[11px] leading-relaxed text-lime-300/90">
                    <code>{item.code}</code>
                  </pre>
                </div>
              ))}
            </div>

            <div className="mt-4 rounded-xl border border-line bg-[#080910] p-3.5">
              <p className="font-mono text-[10px] uppercase tracking-wider text-zinc-500">自检命令</p>
              <CodeView
                code={`# 1) 不带签名 → 必须 403，且响应中没有任何源码\ncurl -o /dev/null -w "%{http_code}" "${baseUrl}/api/raw/<slug>"\n\n# 2) 伪造浏览器 UA → 也必须 403\ncurl -A "Mozilla/5.0" "${baseUrl}/api/raw/<slug>?key=<token>" -o /dev/null -w "%{http_code}"\n\n# 3) 带签名 + 执行器 UA → 200 纯文本源码\ncurl -A "Roblox/WinInet" "${baseUrl}/api/raw/<slug>?key=<token>"`}
                showLineNumbers={false}
                maxHeight="14rem"
              />
            </div>
          </section>

          <section id="errors" className="card scroll-mt-24 p-5">
            <h2 className="text-[17px] font-semibold text-white">状态码</h2>
            <div className="mt-3 overflow-hidden rounded-lg border border-line">
              <table className="w-full text-left text-[12px]">
                <tbody className="divide-y divide-line/70">
                  {[
                    ["200 / 201", "请求成功", "text-lime-300"],
                    ["400", "参数校验失败，error 字段说明原因", "text-amber-300"],
                    ["403", "编辑密钥无效", "text-amber-300"],
                    ["404", "脚本不存在或已被删除", "text-rose-300"],
                    ["409", "自定义短链已被占用", "text-rose-300"],
                    ["500", "服务端错误，可稍后重试", "text-rose-300"],
                    ["503", "数据库暂不可用，raw 接口会返回 Lua warn，可重试", "text-rose-300"],
                  ].map(([code, desc, color]) => (
                    <tr key={code}>
                      <td className={`w-28 px-3 py-2 font-mono ${color}`}>{code}</td>
                      <td className="px-3 py-2 text-zinc-400">{desc}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="mt-3 text-[11.5px] leading-relaxed text-zinc-600">
              所有错误响应形如 <code className="font-mono">{'{"error":"..."}'}</code>。请不要在公共脚本中硬编码编辑密钥。
            </p>
          </section>

          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-brand/25 bg-brand/[0.07] px-4 py-3.5">
            <p className="text-[12.5px] text-zinc-300">准备试试了吗？上传一个脚本就能立刻拿到可用链接。</p>
            <Link href="/new" className="btn btn-primary !py-2">上传脚本</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
