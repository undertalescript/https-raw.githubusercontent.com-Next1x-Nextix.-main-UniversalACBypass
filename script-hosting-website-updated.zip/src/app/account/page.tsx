import Link from "next/link";
import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { AccountClient, type AccountScript } from "@/components/account-client";
import { OwnerConsole } from "@/components/owner-console";
import { PasswordForm } from "@/components/password-form";
import { getSessionUser, isAdminUser } from "@/lib/auth";
import { getScriptsByOwner } from "@/lib/queries";
import { getBaseUrl, loadstringFor, pathUrlFor, rawUrlFor } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "账号中心",
  robots: { index: false, follow: false },
};

export default async function AccountPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login?next=/account");
  const isAdmin = isAdminUser(user);

  const [baseUrl, rows] = await Promise.all([getBaseUrl(), getScriptsByOwner(user.id)]);

  const scripts: AccountScript[] = rows.map((row) => ({
    slug: row.slug,
    title: row.title,
    description: row.description,
    visibility: row.visibility,
    tags: row.tags,
    views: row.views,
    runs: row.runs,
    likes: row.likes,
    obfuscation: row.obfuscation,
    inflation: row.inflation,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
    codeLength: row.codeLength,
    loadstring: loadstringFor(baseUrl, row.slug, row.accessToken),
    rawUrl: rawUrlFor(baseUrl, row.slug, row.accessToken),
    pathUrl: pathUrlFor(baseUrl, row.slug, row.accessToken),
  }));

  return (
    <div className="mx-auto max-w-5xl px-5 py-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-2">/ account</p>
          <h1 className="mt-2 text-[30px] font-semibold tracking-tight text-white">
            你好，<span className="text-brand-2">{user.username}</span>
          </h1>
          <p className="mt-2 max-w-xl text-[13.5px] leading-relaxed text-zinc-500">
            账号内的脚本默认开启源码保护：直接访问 raw 链接会被拒绝（403），只有执行器携带签名才能读取代码。
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {isAdmin && (
            <a
              href="#owner"
              className="btn !border-rose-500/40 !bg-rose-500/15 !text-rose-200 !py-2.5"
            >
              👑 站长控制台（本页）
            </a>
          )}
          <Link href="/new" className="btn btn-primary">
            <span className="text-base leading-none">+</span> 上传脚本
          </Link>
        </div>
      </div>

      {isAdmin && (
        <div className="mt-7">
          <OwnerConsole username={user.username} />
        </div>
      )}

      <div className="mt-7 flex items-end justify-between gap-3">
        <div>
          <h2 className="text-[17px] font-semibold tracking-tight text-white">我的脚本</h2>
          <p className="mt-1 text-[12px] text-zinc-500">
            {isAdmin ? "下方是站长专属控制台" : "上传后可复制 loadstring、查看源码、重置签名或删除。"}
          </p>
        </div>
      </div>

      <div className="mt-4">
        <AccountClient initial={scripts} username={user.username} />
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <div className="card p-4">
          <p className="text-[12.5px] font-medium text-zinc-300">源码保护说明</p>
          <ul className="mt-2 space-y-1.5 text-[11.5px] leading-relaxed text-zinc-500">
            <li>· 直链必须带每个脚本独有的 <code className="font-mono text-zinc-400">?key=</code> 签名。</li>
            <li>· 浏览器 / curl / 爬虫访问一律 403，不会返回任何代码。</li>
            <li>· 怀疑链接外泄时可「重置签名」，旧链接立即失效。</li>
          </ul>
        </div>
        <PasswordForm />
        <div className="card p-4">
          <p className="text-[12.5px] font-medium text-zinc-300">其他入口</p>
          <div className="mt-2 flex flex-col gap-1.5 text-[11.5px]">
            <Link href="/manage" className="text-brand-2 hover:underline">本地编辑密钥托管（未登录时上传的脚本）</Link>
            <Link href="/docs#protection" className="text-brand-2 hover:underline">源码保护机制与 API 文档</Link>
            <Link href="/scripts" className="text-brand-2 hover:underline">浏览社区脚本</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
