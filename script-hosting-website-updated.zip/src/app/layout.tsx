import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import { headers } from "next/headers";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { getSessionUser, isAdminUser } from "@/lib/auth";
import { getSiteSettings } from "@/lib/settings";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "loadbin · Luau 脚本托管与 loadstring 分享",
    template: "%s · loadbin",
  },
  description:
    "loadbin 是面向 Luau / Roblox 脚本作者的托管平台：粘贴代码，一键获得永久可用的 loadstring 链接，内置版本管理、调用统计与评论。",
  keywords: ["loadstring", "Luau", "Roblox 脚本", "脚本托管", "script hosting", "loadbin"],
  openGraph: {
    title: "loadbin · 脚本托管与 loadstring 分享",
    description: "一行 loadstring，托管你的 Luau 脚本。",
    type: "website",
  },
};

const MAINTENANCE_ALLOWED = ["/login", "/register", "/admin", "/maintenance"];

export default async function RootLayout({ children }: { children: ReactNode }) {
  const [user, settings, headerStore] = await Promise.all([
    getSessionUser(),
    getSiteSettings(),
    headers(),
  ]);

  const pathname = headerStore.get("x-pathname") ?? "/";
  const isAdmin = isAdminUser(user);
  const isApi = pathname.startsWith("/api/") || pathname.startsWith("/_next/");
  const showMaintenance =
    settings.maintenanceMode &&
    !isAdmin &&
    !isApi &&
    !MAINTENANCE_ALLOWED.some((prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`));
  return (
    <html lang="zh-CN">
      <body className="min-h-screen bg-void text-zinc-200 antialiased">
        <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
          <div className="absolute inset-0 grid-bg opacity-[0.35]" />
          <div className="absolute -left-40 -top-40 h-[38rem] w-[38rem] rounded-full bg-brand/15 blur-[130px]" />
          <div className="absolute -right-32 top-24 h-[26rem] w-[26rem] rounded-full bg-[#22d3ee]/10 blur-[120px]" />
          <div className="absolute inset-x-0 top-0 h-[520px] bg-gradient-to-b from-brand/[0.07] via-transparent to-transparent" />
        </div>
        <SiteHeader
          user={user ? { id: user.id, username: user.username, role: user.role } : null}
        />
        {settings.announcement.trim() && !showMaintenance && (
          <div className="border-b border-amber-400/20 bg-amber-400/[0.07]">
            <div className="mx-auto flex max-w-6xl items-start gap-2 px-5 py-2.5">
              <span className="mt-0.5 text-[11px] text-amber-300">📢</span>
              <p className="text-[12px] leading-relaxed text-amber-100/90">{settings.announcement}</p>
            </div>
          </div>
        )}
        {!settings.scriptsEnabled && !showMaintenance && (
          <div className="border-b border-rose-500/25 bg-rose-500/[0.08]">
            <div className="mx-auto flex max-w-6xl items-start gap-2 px-5 py-2.5">
              <span className="mt-0.5 text-[11px] text-rose-300">●</span>
              <p className="text-[12px] leading-relaxed text-rose-200/90">
                站长已暂停全站脚本执行，所有 loadstring 请求会返回 503（warn），脚本暂时无法运行。
              </p>
            </div>
          </div>
        )}
        <main>
          {showMaintenance ? (
            <div className="mx-auto grid min-h-[62vh] max-w-2xl place-items-center px-5 py-16">
              <div className="card w-full p-8 text-center">
                <span className="mx-auto grid h-12 w-12 place-items-center rounded-xl border border-amber-400/30 bg-amber-400/10 text-[20px]">
                  🛠
                </span>
                <p className="mt-4 font-mono text-[11px] uppercase tracking-[0.18em] text-amber-300">
                  maintenance mode
                </p>
                <h1 className="mt-2 text-[22px] font-semibold text-white">站点维护中</h1>
                <p className="mx-auto mt-2 max-w-sm text-[12.5px] leading-relaxed text-zinc-500">
                  {settings.announcement.trim() ||
                    "站长正在升级服务，脚本执行与浏览暂时暂停，请稍后再来。"}
                </p>
                <div className="mt-5 flex flex-wrap justify-center gap-2">
                  <Link href="/login" className="btn btn-primary !py-2">站长登录</Link>
                  <Link href="/maintenance" className="btn btn-ghost !py-2">查看状态</Link>
                </div>
              </div>
            </div>
          ) : (
            children
          )}
        </main>
        <SiteFooter />
      </body>
    </html>
  );
}
