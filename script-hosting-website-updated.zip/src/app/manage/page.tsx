import Link from "next/link";
import type { Metadata } from "next";
import { ManageClient } from "@/components/manage-client";
import { getBaseUrl } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "我的托管",
  description: "管理你上传到 loadbin 的脚本：更新代码、复制 loadstring、删除脚本。",
};

export default async function ManagePage() {
  const baseUrl = await getBaseUrl();

  return (
    <div className="mx-auto max-w-4xl px-5 py-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-2">/ dashboard</p>
          <h1 className="mt-2 text-[30px] font-semibold tracking-tight text-white">我的托管</h1>
          <p className="mt-2 max-w-xl text-[13.5px] leading-relaxed text-zinc-500">
            这里列出当前浏览器保存过的脚本。loadbin 不收集账号信息，编辑密钥就是你的凭证。
          </p>
        </div>
        <Link href="/new" className="btn btn-primary">
          <span className="text-base leading-none">+</span> 上传脚本
        </Link>
      </div>

      <div className="mt-8">
        <ManageClient baseUrl={baseUrl} />
      </div>
    </div>
  );
}
