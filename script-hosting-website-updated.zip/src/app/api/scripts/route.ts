import { db } from "@/db";
import { scripts } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import {
  asString,
  cleanTags,
  generateSlug,
  isUniqueViolation,
  isValidCustomSlug,
  jsonError,
  newEditKey,
  readJson,
} from "@/lib/api-helpers";
import { getSessionUser } from "@/lib/auth";
import { normalizeInflation, normalizeObfuscation } from "@/lib/obfuscate";
import { listScripts, normalizePage, normalizeSort } from "@/lib/queries";
import { getBaseUrl, loadstringFor, pageUrlFor, rawUrlFor } from "@/lib/site";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  await ensureSeeded();
  const { searchParams } = new URL(request.url);
  const perPage = Math.min(Math.max(Number(searchParams.get("perPage") ?? 12) || 12, 1), 30);

  const result = await listScripts({
    q: searchParams.get("q"),
    tag: searchParams.get("tag"),
    sort: normalizeSort(searchParams.get("sort")),
    page: normalizePage(searchParams.get("page")),
    perPage,
  });

  return Response.json({
    ok: true,
    scripts: result.items,
    pagination: {
      page: result.page,
      perPage: result.perPage,
      total: result.total,
      totalPages: result.totalPages,
    },
  });
}

export async function POST(request: Request) {
  const body = await readJson(request);

  const title = asString(body.title, 120);
  const code = typeof body.code === "string" ? body.code.slice(0, 300_000) : "";
  const description = asString(body.description, 800);
  const authorName = asString(body.authorName, 40) || "匿名";
  const language = ["luau", "lua"].includes(String(body.language)) ? String(body.language) : "luau";
  const visibility = body.visibility === "unlisted" ? "unlisted" : "public";
  const obfuscation = normalizeObfuscation(body.obfuscation);
  const inflation = normalizeInflation(body.inflation);
  const tags = cleanTags(body.tags);
  const requestedSlug = typeof body.slug === "string" ? body.slug.trim().toLowerCase() : "";

  if (title.length < 3) return jsonError("标题至少需要 3 个字符");
  if (code.trim().length < 10) return jsonError("脚本代码至少需要 10 个字符");
  if (requestedSlug && !isValidCustomSlug(requestedSlug)) {
    return jsonError("短链只能包含小写字母、数字和连字符（2-61 位）");
  }

  const editKey = newEditKey();
  const baseUrl = await getBaseUrl();
  const user = await getSessionUser();

  for (let attempt = 0; attempt < 6; attempt += 1) {
    const slug = requestedSlug || generateSlug(title);
    try {
      const [created] = await db
        .insert(scripts)
        .values({
          slug,
          title,
          description,
          code,
          language,
          tags,
          authorName,
          visibility,
          editKey,
          obfuscation,
          inflation,
          ownerId: user?.id ?? null,
        })
        .returning({
          slug: scripts.slug,
          title: scripts.title,
          accessToken: scripts.accessToken,
          createdAt: scripts.createdAt,
        });

      if (!created) return jsonError("创建失败，请重试", 500);

      return Response.json(
        {
          ok: true,
          owned: Boolean(user),
          script: {
            slug: created.slug,
            title: created.title,
            editKey,
            createdAt: created.createdAt,
            pageUrl: pageUrlFor(baseUrl, created.slug),
            rawUrl: rawUrlFor(baseUrl, created.slug, created.accessToken),
            loadstring: loadstringFor(baseUrl, created.slug, created.accessToken),
            sourceProtected: true,
            obfuscation,
            inflation,
          },
        },
        { status: 201 },
      );
    } catch (error) {
      if (isUniqueViolation(error)) {
        if (requestedSlug) return jsonError("这个短链已经被占用了，换一个试试", 409);
        continue;
      }
      console.error("[api/scripts] create failed", error);
      return jsonError("创建失败，请稍后再试", 500);
    }
  }

  return jsonError("短链生成失败，请重试", 500);
}
