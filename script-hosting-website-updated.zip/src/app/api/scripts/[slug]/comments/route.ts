import { eq } from "drizzle-orm";
import { db } from "@/db";
import { comments, scripts } from "@/db/schema";
import { asString, jsonError, readJson } from "@/lib/api-helpers";
import { getComments } from "@/lib/queries";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ slug: string }> };

async function scriptIdFor(slug: string): Promise<number | null> {
  const [row] = await db.select({ id: scripts.id }).from(scripts).where(eq(scripts.slug, slug)).limit(1);
  return row?.id ?? null;
}

export async function GET(_request: Request, context: RouteContext) {
  const { slug } = await context.params;
  const scriptId = await scriptIdFor(slug);
  if (!scriptId) return jsonError("脚本不存在", 404);

  const items = await getComments(scriptId);
  return Response.json({ ok: true, comments: items });
}

export async function POST(request: Request, context: RouteContext) {
  const { slug } = await context.params;
  const body = await readJson(request);

  const scriptId = await scriptIdFor(slug);
  if (!scriptId) return jsonError("脚本不存在", 404);

  const authorName = asString(body.authorName, 40) || "匿名";
  const text = asString(body.body, 500);
  if (text.length < 2) return jsonError("评论至少需要 2 个字符");

  const [created] = await db
    .insert(comments)
    .values({ scriptId, authorName, body: text })
    .returning();

  return Response.json({ ok: true, comment: created }, { status: 201 });
}
