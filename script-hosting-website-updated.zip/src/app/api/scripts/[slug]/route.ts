import { eq } from "drizzle-orm";
import { randomBytes } from "node:crypto";
import { db } from "@/db";
import { scripts } from "@/db/schema";
import { asString, cleanTags, jsonError, readJson } from "@/lib/api-helpers";
import { getSessionUser, isAdminUser } from "@/lib/auth";
import { normalizeInflation, normalizeObfuscation } from "@/lib/obfuscate";
import { getBaseUrl, loadstringFor, pageUrlFor, rawUrlFor } from "@/lib/site";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ slug: string }> };

function keyFrom(request: Request, body?: Record<string, unknown>): string {
  return (
    request.headers.get("x-edit-key")?.trim() ||
    new URL(request.url).searchParams.get("key")?.trim() ||
    (typeof body?.editKey === "string" ? body.editKey.trim() : "")
  );
}

async function findScript(slug: string) {
  const rows = await db.select().from(scripts).where(eq(scripts.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function GET(request: Request, context: RouteContext) {
  const { slug } = await context.params;
  const row = await findScript(slug);
  if (!row) return jsonError("脚本不存在或已被删除", 404);

  const baseUrl = await getBaseUrl();
  const user = await getSessionUser();
  const key = keyFrom(request);
  const isOwner =
    Boolean(user && row.ownerId === user.id) ||
    isAdminUser(user) ||
    (Boolean(key) && key === row.editKey);

  const { editKey: _editKey, accessToken, code, ...meta } = row;

  // The signed loader is a secret: never hand it to anonymous API callers.
  return Response.json({
    ok: true,
    canEdit: isOwner,
    pageUrl: pageUrlFor(baseUrl, row.slug),
    ...(isOwner
      ? {
          loadstring: loadstringFor(baseUrl, row.slug, accessToken),
          rawUrl: rawUrlFor(baseUrl, row.slug, accessToken),
        }
      : {}),
    script: isOwner ? { ...meta, code, accessToken } : meta,
  });
}

export async function PATCH(request: Request, context: RouteContext) {
  const { slug } = await context.params;
  const body = await readJson(request);
  const key = keyFrom(request, body);

  const row = await findScript(slug);
  if (!row) return jsonError("脚本不存在或已被删除", 404);

  const user = await getSessionUser();
  const isOwner =
    Boolean(user && row.ownerId === user.id) ||
    isAdminUser(user) ||
    (Boolean(key) && key === row.editKey);
  if (!isOwner) return jsonError("没有权限修改该脚本", 403);

  const baseUrl = await getBaseUrl();

  if (body.regenerateToken === true) {
    const accessToken = randomBytes(16).toString("hex");
    const [updated] = await db
      .update(scripts)
      .set({ accessToken, updatedAt: new Date() })
      .where(eq(scripts.id, row.id))
      .returning();
    if (!updated) return jsonError("重置失败", 500);
    return Response.json({
      ok: true,
      accessToken,
      loadstring: loadstringFor(baseUrl, updated.slug, accessToken),
      rawUrl: rawUrlFor(baseUrl, updated.slug, accessToken),
    });
  }

  const patch: Partial<typeof scripts.$inferInsert> = { updatedAt: new Date() };

  if (body.title !== undefined) {
    const title = asString(body.title, 120);
    if (title.length < 3) return jsonError("标题至少需要 3 个字符");
    patch.title = title;
  }
  if (body.description !== undefined) patch.description = asString(body.description, 800);
  if (body.authorName !== undefined) patch.authorName = asString(body.authorName, 40) || "匿名";
  if (body.code !== undefined) {
    const code = typeof body.code === "string" ? body.code.slice(0, 300_000) : "";
    if (code.trim().length < 10) return jsonError("脚本代码至少需要 10 个字符");
    patch.code = code;
  }
  if (body.tags !== undefined) patch.tags = cleanTags(body.tags);
  if (body.visibility !== undefined) {
    patch.visibility = body.visibility === "unlisted" ? "unlisted" : "public";
  }
  if (body.obfuscation !== undefined) {
    patch.obfuscation = normalizeObfuscation(body.obfuscation);
  }
  if (body.inflation !== undefined) {
    patch.inflation = normalizeInflation(body.inflation);
  }

  const [updated] = await db.update(scripts).set(patch).where(eq(scripts.id, row.id)).returning();
  if (!updated) return jsonError("保存失败", 500);

  const { editKey: _editKey, ...safe } = updated;
  return Response.json({ ok: true, script: safe });
}

export async function DELETE(request: Request, context: RouteContext) {
  const { slug } = await context.params;
  const key = keyFrom(request);
  const row = await findScript(slug);

  if (!row) return jsonError("脚本不存在或已被删除", 404);

  const user = await getSessionUser();
  const isOwner =
    Boolean(user && row.ownerId === user.id) ||
    isAdminUser(user) ||
    (Boolean(key) && key === row.editKey);
  if (!isOwner) return jsonError("没有权限删除该脚本", 403);

  await db.delete(scripts).where(eq(scripts.id, row.id));
  return Response.json({ ok: true, deleted: slug });
}
