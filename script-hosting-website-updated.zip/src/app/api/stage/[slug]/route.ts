import { areScriptsEnabled } from "@/lib/settings";
import { lookupStage } from "@/lib/stage";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ slug: string }> };

const HEADERS = {
  "content-type": "text/plain; charset=utf-8",
  "cache-control": "no-store",
  "access-control-allow-origin": "*",
  "x-robots-tag": "noindex, nofollow",
  "x-content-type-options": "nosniff",
};

export async function GET(request: Request, context: RouteContext) {
  const { slug } = await context.params;
  const url = new URL(request.url);

  // Browsers and humans get nothing: this endpoint only serves executors.
  const accept = (request.headers.get("accept") ?? "").toLowerCase();
  const mode = (request.headers.get("sec-fetch-mode") ?? "").toLowerCase();
  if (mode === "navigate" || accept.includes("text/html")) {
    return new Response("-- stage endpoint: executor only", { status: 403, headers: HEADERS });
  }

  if (!(await areScriptsEnabled())) {
    return new Response('warn("[loadbin] execution paused by the site owner")', { status: 200, headers: HEADERS });
  }

  const key = url.searchParams.get("key") ?? "";
  const nonce = url.searchParams.get("n") ?? "";
  const result = await lookupStage(slug, key, nonce);

  if (!result.ok) {
    const message =
      result.reason === "nonce"
        ? "staged link expired, reload the script page and copy the loadstring again"
        : result.reason === "signature"
          ? "invalid signature for staged payload"
          : result.reason === "disabled"
            ? "this script is disabled"
            : `unknown script: ${slug.replace(/[^a-z0-9-]/gi, "")}`;
    return new Response(`warn("[loadbin] ${message}")`, {
      status: 200,
      headers: { ...HEADERS, "x-loadbin-stage": result.reason },
    });
  }

  return new Response(result.stage, {
    status: 200,
    headers: { ...HEADERS, "x-loadbin-stage": "ok", "content-length": String(Buffer.byteLength(result.stage)) },
  });
}

export async function HEAD() {
  return new Response(null, { status: 204, headers: HEADERS });
}

