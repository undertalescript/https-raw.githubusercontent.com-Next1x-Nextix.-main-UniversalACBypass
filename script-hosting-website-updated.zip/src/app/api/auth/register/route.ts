import { asString, isUniqueViolation, jsonError, readJson } from "@/lib/api-helpers";
import {
  createSession,
  hashPassword,
  normalizeUsername,
  validatePassword,
  validateUsername,
} from "@/lib/auth";
import { db } from "@/db";
import { users } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = await readJson(request);
  const username = normalizeUsername(asString(body.username, 32));
  const password = typeof body.password === "string" ? body.password : "";

  const usernameError = validateUsername(username);
  if (usernameError) return jsonError(usernameError);
  const passwordError = validatePassword(password);
  if (passwordError) return jsonError(passwordError);

  try {
    const passwordHash = await hashPassword(password);
    const [created] = await db
      .insert(users)
      .values({ username, passwordHash })
      .returning({ id: users.id, username: users.username, createdAt: users.createdAt });

    if (!created) return jsonError("注册失败，请重试", 500);
    await createSession(created.id);

    return Response.json({ ok: true, user: created }, { status: 201 });
  } catch (error) {
    if (isUniqueViolation(error)) return jsonError("这个用户名已经被注册了", 409);
    console.error("[auth/register] failed", error);
    return jsonError("注册失败，请稍后再试", 500);
  }
}
