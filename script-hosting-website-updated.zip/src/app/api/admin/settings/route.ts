import { jsonError, readJson } from "@/lib/api-helpers";
import { getAdminUser } from "@/lib/auth";
import { getSiteSettings, updateSiteSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await getAdminUser();
  if (!admin) return jsonError("需要站长权限", 403);
  return Response.json({ ok: true, settings: await getSiteSettings() });
}

export async function PATCH(request: Request) {
  const admin = await getAdminUser();
  if (!admin) return jsonError("需要站长权限", 403);

  const body = await readJson(request);
  const patch: Parameters<typeof updateSiteSettings>[0] = { updatedBy: admin.username };

  if (typeof body.scriptsEnabled === "boolean") patch.scriptsEnabled = body.scriptsEnabled;
  if (typeof body.maintenanceMode === "boolean") patch.maintenanceMode = body.maintenanceMode;
  if (typeof body.announcement === "string") patch.announcement = body.announcement.slice(0, 280);

  const settings = await updateSiteSettings(patch);
  return Response.json({ ok: true, settings });
}
