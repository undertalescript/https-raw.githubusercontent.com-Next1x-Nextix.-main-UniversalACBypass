import { eq } from "drizzle-orm";
import { db } from "@/db";
import { scripts } from "@/db/schema";
import { jsonError, readJson } from "@/lib/api-helpers";
import { getAdminUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ slug: string }> };

export async function PATCH(request: Request, context: RouteContext) {
  const admin = await getAdminUser();
  if (!admin) return jsonError("需要站长权限", 403);

  const { slug } = await context.params;
  const body = await readJson(request);

  const [row] = await db.select({ id: scripts.id }).from(scripts).where(eq(scripts.slug, slug)).limit(1);
  if (!row) return jsonError("脚本不存在", 404);

  const [updated] = await db
    .update(scripts)
    .set({
      ...(typeof body.disabled === "boolean" ? { disabled: body.disabled } : {}),
      updatedAt: new Date(),
    })
    .where(eq(scripts.id, row.id))
    .returning({ slug: scripts.slug, disabled: scripts.disabled });

  return Response.json({ ok: true, script: updated });
}

export async function DELETE(_request: Request, context: RouteContext) {
  const admin = await getAdminUser();
  if (!admin) return jsonError("需要站长权限", 403);

  const { slug } = await context.params;
  const deleted = await db
    .delete(scripts)
    .where(eq(scripts.slug, slug))
    .returning({ slug: scripts.slug });

  if (!deleted[0]) return jsonError("脚本不存在", 404);
  return Response.json({ ok: true, deleted: deleted[0].slug });
}
