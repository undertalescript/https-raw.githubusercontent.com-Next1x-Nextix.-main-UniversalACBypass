import { rawPreflight, serveRawScript } from "@/lib/raw-serve";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ key: string; slug: string }> };

/**
 * Signature-in-path variant: `/k/<accessToken>/<slug>`.
 * Some executors strip or mangle query strings, so this form always works.
 */
export async function GET(request: Request, context: RouteContext) {
  const { key, slug } = await context.params;
  return serveRawScript(request, slug, key);
}

export async function HEAD(request: Request, context: RouteContext) {
  const { key, slug } = await context.params;
  return serveRawScript(request, slug, key);
}

export async function OPTIONS() {
  return rawPreflight();
}
