"use client";

import { useState } from "react";
import { cn } from "@/lib/format";

export function PasswordForm() {
  const [open, setOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [pending, setPending] = useState(false);
  const [notice, setNotice] = useState<{ type: "ok" | "error"; text: string } | null>(null);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setNotice(null);
    try {
      const response = await fetch("/api/auth/password", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(data.error ?? "修改失败");
      setNotice({ type: "ok", text: "密码已更新，下次登录请使用新密码。" });
      setCurrentPassword("");
      setNewPassword("");
      setOpen(false);
    } catch (cause) {
      setNotice({ type: "error", text: cause instanceof Error ? cause.message : "修改失败" });
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="rounded-lg border border-line bg-white/[0.015] p-3">
      <div className="flex items-center justify-between gap-2">
        <p className="text-[12px] font-medium text-zinc-300">登录密码</p>
        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          className="text-[11.5px] text-brand-2 hover:underline"
        >
          {open ? "收起" : "修改密码"}
        </button>
      </div>

      {notice && (
        <p
          className={cn(
            "mt-2 text-[11.5px]",
            notice.type === "ok" ? "text-lime-300" : "text-rose-300",
          )}
        >
          {notice.text}
        </p>
      )}

      {open && (
        <form onSubmit={submit} className="mt-2.5 space-y-2">
          <input
            type="password"
            value={currentPassword}
            onChange={(event) => setCurrentPassword(event.target.value)}
            placeholder="当前密码"
            required
            className="field !py-1.5 font-mono !text-[11.5px]"
          />
          <input
            type="password"
            value={newPassword}
            onChange={(event) => setNewPassword(event.target.value)}
            placeholder="新密码（至少 6 位）"
            required
            minLength={6}
            className="field !py-1.5 font-mono !text-[11.5px]"
          />
          <button type="submit" disabled={pending} className="btn btn-primary w-full !py-1.5 !text-[11.5px] disabled:opacity-60">
            {pending ? "保存中…" : "保存新密码"}
          </button>
        </form>
      )}
    </div>
  );
}
