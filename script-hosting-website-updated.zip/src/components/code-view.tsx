import { cn } from "@/lib/format";

const TOKEN_RE = new RegExp(
  [
    "(--\\[\\[[\\s\\S]*?\\]\\]|--[^\\n]*)", // 1 comment
    "(\"(?:[^\"\\\\\\n]|\\\\.)*\"|'(?:[^'\\\\\\n]|\\\\.)*')", // 2 string
    "(\\b\\d+(?:\\.\\d+)?\\b)", // 3 number
    "(\\b(?:local|function|end|if|then|else|elseif|for|do|while|repeat|until|return|break|and|or|not|in|nil|true|false|continue|export|type)\\b)", // 4 keyword
    "(\\b(?:game|workspace|script|Instance|task|wait|print|warn|pcall|require|loadstring|setmetatable|getmetatable|tostring|tonumber|ipairs|pairs|table|string|math|os|Enum|Vector2|Vector3|CFrame|UDim|UDim2|Color3|Random|self|request)\\b)", // 5 global
    "([A-Za-z_]\\w*)(?=\\s*\\()", // 6 call
    "([{}()\\[\\]:.,;=+\\-*/%#<>~^|&!])", // 7 punct
  ].join("|"),
  "g",
);

const CLASSES = [
  "text-zinc-500 italic",
  "text-lime-300",
  "text-amber-300",
  "text-violet-300",
  "text-sky-300",
  "text-cyan-200",
  "text-zinc-500",
];

function highlight(code: string) {
  const nodes: React.ReactNode[] = [];
  let lastIndex = 0;
  let key = 0;

  for (const match of code.matchAll(TOKEN_RE)) {
    const index = match.index ?? 0;
    if (index > lastIndex) {
      nodes.push(code.slice(lastIndex, index));
    }
    const groupIndex = match.slice(1).findIndex((group) => group !== undefined);
    nodes.push(
      <span key={key++} className={CLASSES[groupIndex] ?? ""}>
        {match[0]}
      </span>,
    );
    lastIndex = index + match[0].length;
  }

  if (lastIndex < code.length) nodes.push(code.slice(lastIndex));
  return nodes;
}

type CodeViewProps = {
  code: string;
  className?: string;
  maxHeight?: string;
  showLineNumbers?: boolean;
  wrap?: boolean;
};

export function CodeView({
  code,
  className,
  maxHeight = "32rem",
  showLineNumbers = true,
  wrap = false,
}: CodeViewProps) {
  const lineCount = code.split("\n").length;
  const lineNumbers = Array.from({ length: lineCount }, (_, index) => index + 1).join("\n");

  return (
    <div
      className={cn(
        "code-scroll relative overflow-auto rounded-xl border border-line bg-[#07080d]",
        className,
      )}
      style={{ maxHeight }}
    >
      <div className="flex min-w-full text-[12.5px] leading-[1.75]">
        {showLineNumbers && (
          <div className="sticky left-0 z-10 shrink-0 select-none border-r border-line/70 bg-[#080910] px-3 py-4 text-right font-mono text-zinc-600">
            <pre className="m-0">{lineNumbers}</pre>
          </div>
        )}
        <pre
          className={cn(
            "m-0 flex-1 px-4 py-4 font-mono text-zinc-300",
            wrap ? "whitespace-pre-wrap break-words" : "whitespace-pre",
          )}
        >
          <code>{highlight(code)}</code>
        </pre>
      </div>
    </div>
  );
}
