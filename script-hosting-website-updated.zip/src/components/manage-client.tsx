"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { CopyButton } from "@/components/copy-button";
import { cn, formatNumber, timeAgo } from "@/lib/format";
import { forgetScript, readRememberedScripts, rememberScript } from "@/lib/local-store";

type ScriptMeta = {
  slug: string;
  title: string;
  description: string;
  visibility: string;
  tags: string[];
  views: number;
  runs: number;
  likes: number;
  updatedAt: string;
};

type Row = {
  slug: string;
  title: string;
  editKey: string;
  status: "loading" | "ok" | "missing" | "error";
  canEdit?: boolean;
  meta?: ScriptMeta;
  loadstring?: string;
  rawUrl?: string;
};

export function ManageClient({ baseUrl }: { baseUrl: string }) {
  const [rows, setRows] = useState<Row[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [importSlug, setImportSlug] = useState("");
  const [importKey, setImportKey] = useState("");
  const [importError, setImportError] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);

  const patchRow = useCallback((slug: string, patch: Partial<Row>) => {
    setRows((current) => current.map((row) => (row.slug === slug ? { ...row, ...patch } : row)));
  }, []);

  const loadMeta = useCallback(
    async (row: Pick<Row, "slug" | "editKey">) => {
      try {
        const response = await fetch(
          `/api/scripts/${encodeURIComponent(row.slug)}?key=${encodeURIComponent(row.editKey)}`,
          { cache: "no-store" },
        );
        if (response.status === 404) {
          patchRow(row.slug, { status: "missing" });
          return;
        }
        if (!response.ok) {
          patchRow(row.slug, { status: "error" });
          return;
        }
        const data = (await response.json()) as {
          script?: ScriptMeta;
          canEdit?: boolean;
          loadstring?: string;
          rawUrl?: string;
        };
        if (!data.script) {
          patchRow(row.slug, { status: "error" });
          return;
        }
        patchRow(row.slug, {
          status: "ok",
          meta: data.script,
          canEdit: Boolean(data.canEdit),
          loadstring: data.loadstring,
          rawUrl: data.rawUrl,
        });
      } catch {
        patchRow(row.slug, { status: "error" });
      }
    },
    [patchRow],
  );

  useEffect(() => {
    const stored = readRememberedScripts();
    setRows(stored.map((item) => ({ ...item, status: "loading" as const })));
    setHydrated(true);
    stored.forEach((item) => void loadMeta(item));
  }, [loadMeta]);

  async function remove(row: Row) {
    if (!window.confirm(`确定删除「${row.meta?.title ?? row.title}」？该操作不可撤销。`)) return;
    try {
      const response = await fetch(`/api/scripts/${encodeURIComponent(row.slug)}`, {
        method: "DELETE",
        headers: { "x-edit-key": row.editKey },
      });
      if (!response.ok && response.status !== 404) {
        const data = (await response.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error ?? "删除失败");
      }
      forgetScript(row.slug);
      setRows((current) => current.filter((item) => item.slug !== row.slug));
    } catch (cause) {
      window.alert(cause instanceof Error ? cause.message : "删除失败");
    }
  }

  async function importScript(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setImportError(null);
    const slug = importSlug.trim();
    const key = importKey.trim();
    if (!slug || !key) return setImportError("请填写短链和编辑密钥");

    setImporting(true);
    try {
      const response = await fetch(
        `/api/scripts/${encodeURIComponent(slug)}?key=${encodeURIComponent(key)}`,
        { cache: "no-store" },
      );
      const data = (await response.json()) as { script?: ScriptMeta; canEdit?: boolean; error?: string };
      if (!response.ok || !data.script) throw new Error(data.error ?? "未找到该脚本");
      if (!data.canEdit) throw new Error("编辑密钥不正确");

      rememberScript({ slug: data.script.slug, title: data.script.title, editKey: key });
      setRows((current) => [
        {
          slug: data.script!.slug,
          title: data.script!.title,
          editKey: key,
          status: "ok",
          canEdit: true,
          meta: data.script,
        },
        ...current.filter((row) => row.slug !== data.script!.slug),
      ]);
      setImportSlug("");
      setImportKey("");
    } catch (cause) {
      setImportError(cause instanceof Error ? cause.message : "导入失败");
    } finally {
      setImporting(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="card p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-[14px] font-semibold text-white">导入已有脚本</h2>
            <p className="mt-1 text-[12px] text-zinc-500">
              换设备或清除浏览器数据后，用短链 + 编辑密钥重新绑定到这里。
            </p>
          </div>
          <span className="chip font-mono">local only</span>
        </div>
        <form onSubmit={importScript} className="mt-4 grid gap-3 sm:grid-cols-[1fr_1fr_auto]">
          <input
            value={importSlug}
            onChange={(event) => setImportSlug(event.target.value)}
            placeholder="脚本短链，例如 orbit-esp-9f3k"
            className="field font-mono !text-[12px]"
          />
          <input
            value={importKey}
            onChange={(event) => setImportKey(event.target.value)}
            placeholder="编辑密钥"
            type="password"
            className="field font-mono !text-[12px]"
          />
          <button type="submit" disabled={importing} className="btn btn-primary disabled:opacity-60">
            {importing ? "校验中…" : "导入"}
          </button>
        </form>
        {importError && <p className="mt-2 text-[12px] text-rose-400">{importError}</p>}
      </div>

      {!hydrated ? (
        <div className="card grid h-40 place-items-center text-[13px] text-zinc-500">正在读取本地密钥…</div>
      ) : rows.length === 0 ? (
        <div className="card grid place-items-center px-6 py-16 text-center">
          <div className="grid h-12 w-12 place-items-center rounded-xl border border-line bg-white/[0.03] text-xl">
            {"{}"}
          </div>
          <h3 className="mt-4 text-[15px] font-semibold text-white">还没有托管记录</h3>
          <p className="mt-2 max-w-sm text-[12.5px] leading-relaxed text-zinc-500">
            上传脚本后，编辑密钥会保存在当前浏览器里。它只存在本地，不会上传到服务器。
          </p>
          <Link href="/new" className="btn btn-primary mt-5">上传第一个脚本</Link>
        </div>
      ) : (
        <div className="space-y-3">
          {rows.map((row) => {
            const slug = row.meta?.slug ?? row.slug;
            const loadstring = row.loadstring ?? "";
            return (
              <div key={row.slug} className="card p-4">
                <div className="flex flex-wrap items-start gap-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <Link
                        href={`/s/${slug}`}
                        className="truncate text-[14px] font-semibold text-white hover:text-brand-2"
                      >
                        {row.meta?.title ?? row.title}
                      </Link>
                      {row.meta?.visibility === "unlisted" && (
                        <span className="chip !text-amber-300">不公开</span>
                      )}
                      {row.status === "loading" && <span className="chip">读取中</span>}
                      {row.status === "missing" && <span className="chip !text-rose-300">已删除</span>}
                      {row.status === "error" && <span className="chip !text-rose-300">读取失败</span>}
                      {row.status === "ok" && !row.canEdit && (
                        <span className="chip !text-amber-300">密钥无效</span>
                      )}
                    </div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-[11px] text-zinc-500">
                      <span>/api/raw/{slug}</span>
                      {row.meta && (
                        <span className="text-zinc-600">
                          👁 {formatNumber(row.meta.views)} · ▶ {formatNumber(row.meta.runs)} · ♥{" "}
                          {formatNumber(row.meta.likes)} · {timeAgo(row.meta.updatedAt)}
                        </span>
                      )}
                    </div>
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      <CopyButton
                        value={loadstring}
                        label="复制 loadstring"
                        variant="lime"
                        className="!py-1.5 !text-[11.5px]"
                      />
                      <CopyButton
                        value={row.rawUrl ?? `${baseUrl}/api/raw/${slug}`}
                        label="复制签名直链"
                        className="!py-1.5 !text-[11.5px]"
                      />
                      <span className="chip !border-lime/25 !bg-lime/10 !text-lime-300">🔒 保护</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Link
                      href={`/s/${slug}/edit?key=${encodeURIComponent(row.editKey)}`}
                      className={cn("btn btn-ghost !py-1.5 !text-[11.5px]", row.status === "missing" && "opacity-50")}
                    >
                      编辑
                    </Link>
                    <button
                      type="button"
                      onClick={() => remove(row)}
                      className="btn !py-1.5 !text-[11.5px] !border-rose-500/30 !bg-rose-500/10 !text-rose-300"
                    >
                      删除
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <p className="text-center text-[11.5px] text-zinc-600">
        密钥仅保存在当前浏览器的 localStorage（键名 loadbin.scripts.v1），不会展示给其他访客。请勿在公共设备上导入。
      </p>
    </div>
  );
}
