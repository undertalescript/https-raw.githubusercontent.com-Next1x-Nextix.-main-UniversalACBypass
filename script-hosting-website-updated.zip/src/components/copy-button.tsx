"use client";

import { useState } from "react";
import { cn } from "@/lib/format";

type CopyButtonProps = {
  value: string;
  label?: string;
  copiedLabel?: string;
  className?: string;
  variant?: "primary" | "ghost" | "lime";
};

export function CopyButton({
  value,
  label = "复制",
  copiedLabel = "已复制",
  className,
  variant = "ghost",
}: CopyButtonProps) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(value);
      } else {
        const area = document.createElement("textarea");
        area.value = value;
        area.style.position = "fixed";
        area.style.opacity = "0";
        document.body.appendChild(area);
        area.select();
        document.execCommand("copy");
        document.body.removeChild(area);
      }
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  }

  const variantClass =
    variant === "primary" ? "btn-primary" : variant === "lime" ? "btn-lime" : "btn-ghost";

  return (
    <button
      type="button"
      onClick={copy}
      className={cn("btn", variantClass, "text-[12px]", className)}
      aria-live="polite"
    >
      <span className="text-[13px] leading-none">{copied ? "✓" : "⧉"}</span>
      {copied ? copiedLabel : label}
    </button>
  );
}
