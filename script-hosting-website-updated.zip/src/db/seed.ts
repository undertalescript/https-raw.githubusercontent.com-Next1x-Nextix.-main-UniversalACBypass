import { eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { comments, scripts, siteSettings, users, type NewScript } from "@/db/schema";
import { hashPassword, verifyPassword } from "@/lib/auth";

const ESP_CODE = `--[[
    Orbit ESP · Universal Highlight Library
    用法: 将本脚本托管后使用 loadstring 执行
]]
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local Camera = workspace.CurrentCamera

local Settings = {
    Enabled = true,
    TeamCheck = false,
    MaxDistance = 900,
    BoxColor = Color3.fromRGB(139, 92, 246),
    TextColor = Color3.fromRGB(255, 255, 255),
}

local function createBox(player)
    local billboard = Instance.new("BillboardGui")
    billboard.Name = "orbit_esp"
    billboard.Size = UDim2.fromOffset(44, 60)
    billboard.AlwaysOnTop = true
    billboard.Adornee = player.Character and player.Character:FindFirstChild("Head")
    billboard.Parent = player.Character and player.Character:FindFirstChild("Head")
    return billboard
end

local function clear()
    for _, player in ipairs(Players:GetPlayers()) do
        local head = player.Character and player.Character:FindFirstChild("Head")
        local gui = head and head:FindFirstChild("orbit_esp")
        if gui then gui:Destroy() end
    end
end

Players.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function()
        task.wait(0.6)
        if Settings.Enabled then createBox(player) end
    end)
end)

RunService.RenderStepped:Connect(function()
    if not Settings.Enabled then return end
    for _, player in ipairs(Players:GetPlayers()) do
        if player ~= Players.LocalPlayer and player.Character then
            local head = player.Character:FindFirstChild("Head")
            if head and not head:FindFirstChild("orbit_esp") then
                createBox(player)
            end
        end
    end
end)

print("[Orbit ESP] loaded · " .. tostring(#Players:GetPlayers()) .. " players tracked")`;

const FARM_CODE = `-- Blox Fruits · Auto Farm (safe mode)
-- 仅用于学习 Luau 自动化逻辑
local player = game.Players.LocalPlayer
local Remotes = game:GetService("ReplicatedStorage"):WaitForChild("Remotes")

local Config = {
    AutoAttack = true,
    AutoQuest = true,
    FarmRadius = 120,
    Delay = 0.35,
}

local function nearestEnemy()
    local best, bestDist = nil, Config.FarmRadius
    for _, mob in ipairs(workspace:GetDescendants()) do
        if mob:IsA("Model") and mob:FindFirstChild("Humanoid") then
            local root = mob:FindFirstChild("HumanoidRootPart")
            local humanoid = mob:FindFirstChildWhichIsA("Humanoid")
            if root and humanoid and humanoid.Health > 0 then
                local dist = (root.Position - player.Character.HumanoidRootPart.Position).Magnitude
                if dist < bestDist then best, bestDist = mob, dist end
            end
        end
    end
    return best
end

task.spawn(function()
    while Config.AutoAttack do
        local target = nearestEnemy()
        if target then
            local char = player.Character
            if char and char:FindFirstChild("HumanoidRootPart") then
                char.HumanoidRootPart.CFrame = target.HumanoidRootPart.CFrame * CFrame.new(0, 0, 4)
            end
            local attack = Remotes:FindFirstChild("Combat")
            if attack then attack:FireServer("Melee", target) end
        end
        task.wait(Config.Delay)
    end
end)

print("[Blox Fruits] auto farm armed · radius " .. Config.FarmRadius)`;

const UI_CODE = `-- Lucid UI · 轻量窗口库 (18kb)
local Lucid = {}
Lucid.__index = Lucid

local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local CoreGui = game:GetService("CoreGui")

local THEME = {
    Background = Color3.fromRGB(11, 12, 18),
    Stroke = Color3.fromRGB(43, 45, 60),
    Accent = Color3.fromRGB(139, 92, 246),
    Text = Color3.fromRGB(236, 238, 248),
    Muted = Color3.fromRGB(140, 144, 168),
}

function Lucid.new(options)
    local self = setmetatable({}, Lucid)
    self.title = options.Title or "Lucid UI"
    self.tabs = {}
    self.connections = {}

    local gui = Instance.new("ScreenGui")
    gui.Name = "lucid_ui_" .. tostring(math.random(1000, 9999))
    gui.ResetOnSpawn = false
    gui.IgnoreGuiInset = true
    gui.Parent = CoreGui

    local frame = Instance.new("Frame")
    frame.Size = UDim2.fromOffset(options.Width or 520, options.Height or 340)
    frame.Position = UDim2.fromScale(0.5, 0.5)
    frame.AnchorPoint = Vector2.new(0.5, 0.5)
    frame.BackgroundColor3 = THEME.Background
    frame.BorderSizePixel = 0
    frame.Parent = gui

    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 12)
    corner.Parent = frame

    local stroke = Instance.new("UIStroke")
    stroke.Color = THEME.Stroke
    stroke.Parent = frame

    self.gui, self.frame = gui, frame
    return self
end

function Lucid:Tab(name)
    local tab = { Name = name, Buttons = {} }
    table.insert(self.tabs, tab)
    return tab
end

function Lucid:Notify(text, duration)
    local note = Instance.new("TextLabel")
    note.Size = UDim2.fromOffset(260, 38)
    note.Position = UDim2.new(1, -280, 1, -60 - (#self.tabs * 44))
    note.BackgroundColor3 = THEME.Background
    note.TextColor3 = THEME.Text
    note.Font = Enum.Font.GothamMedium
    note.TextSize = 13
    note.Text = text
    note.Parent = self.gui

    TweenService:Create(note, TweenInfo.new(0.2), { BackgroundTransparency = 1 }):Play()
    task.delay(duration or 3, function() note:Destroy() end)
end

function Lucid:Destroy()
    for _, connection in ipairs(self.connections) do connection:Disconnect() end
    if self.gui then self.gui:Destroy() end
end

return Lucid`;

const PETS_CODE = `-- Pet Simulator 99 · Auto Hatch
local Players = game:GetService("Players")
local RS = game:GetService("ReplicatedStorage")
local player = Players.LocalPlayer

local Settings = {
    Egg = "Best",
    AutoHatch = true,
    AutoDeleteCommon = true,
    Notify = true,
}

local function getEgg()
    local eggs = workspace:FindFirstChild("Eggs") or RS:FindFirstChild("Eggs")
    if not eggs then return nil end
    local best, bestPrice = nil, -1
    for _, egg in ipairs(eggs:GetChildren()) do
        local price = egg:GetAttribute("Price") or 0
        if price > bestPrice then best, bestPrice = egg, price end
    end
    return best
end

local hatchRemote = RS:FindFirstChild("HatchEgg") or RS:FindFirstChild("Remotes") and RS.Remotes:FindFirstChild("Hatch")

task.spawn(function()
    while Settings.AutoHatch do
        local egg = getEgg()
        if egg and hatchRemote then
            hatchRemote:FireServer(egg.Name, 3)
            if Settings.Notify then
                print("[PS99] hatching " .. egg.Name)
            end
        end
        task.wait(1.2)
    end
end)

player.CharacterAdded:Connect(function()
    task.wait(3)
    print("[PS99] character respawned, hatch loop still active")
end)`;

const AIM_CODE = `-- Spectre Aim · 平滑镜头自瞄
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local Camera = workspace.CurrentCamera
local LocalPlayer = Players.LocalPlayer

local Config = {
    Enabled = true,
    FieldOfView = 120,
    Smoothness = 0.18,
    TeamCheck = true,
    VisibleOnly = true,
}

local function getTarget()
    local closest, distance = nil, Config.FieldOfView
    local origin = Camera.CFrame.Position
    for _, player in ipairs(Players:GetPlayers()) do
        if player ~= LocalPlayer and player.Team ~= LocalPlayer.Team then
            local character = player.Character
            local head = character and character:FindFirstChild("Head")
            if head then
                local screen, onScreen = Camera:WorldToViewportPoint(head.Position)
                if onScreen then
                    local delta = (Vector2.new(screen.X, screen.Y) - Camera.ViewportSize / 2).Magnitude
                    local distanceFromCamera = (head.Position - origin).Magnitude
                    if delta < distance and distanceFromCamera < 900 then
                        closest, distance = head, delta
                    end
                end
            end
        end
    end
    return closest
end

RunService.RenderStepped:Connect(function()
    if not Config.Enabled then return end
    local target = getTarget()
    if target then
        local goal = CFrame.lookAt(Camera.CFrame.Position, target.Position)
        Camera.CFrame = Camera.CFrame:Lerp(goal, Config.Smoothness)
    end
end)

print("[Spectre] aim assist loaded · fov " .. Config.FieldOfView)`;

const ADMIN_CODE = `-- Ripple Admin · 通用管理员面板
local Players = game:GetService("Players")
local Lighting = game:GetService("Lighting")
local LocalPlayer = Players.LocalPlayer

local Commands = {}
local Prefix = ";"

local function resolvePlayer(input)
    if not input then return nil end
    local lowered = string.lower(input)
    for _, player in ipairs(Players:GetPlayers()) do
        if string.sub(string.lower(player.Name), 1, #lowered) == lowered then
            return player
        end
    end
    return nil
end

Commands.walk = function(speed)
    LocalPlayer.Character.Humanoid.WalkSpeed = tonumber(speed) or 16
end

Commands.jump = function(power)
    LocalPlayer.Character.Humanoid.JumpPower = tonumber(power) or 50
end

Commands.tp = function(name)
    local target = resolvePlayer(name)
    if target and target.Character then
        LocalPlayer.Character.HumanoidRootPart.CFrame = target.Character.HumanoidRootPart.CFrame
    end
end

Commands.night = function()
    Lighting.ClockTime = 0
    Lighting.Brightness = 0.4
end

Commands.clear = function()
    for _, item in ipairs(workspace:GetChildren()) do
        if item:IsA("BasePart") and item.Name ~= "Baseplate" then item:Destroy() end
    end
end

LocalPlayer.Chatted:Connect(function(message)
    if string.sub(message, 1, #Prefix) ~= Prefix then return end
    local args = string.split(message, " ")
    local command = string.lower(string.sub(args[1], #Prefix + 1))
    local handler = Commands[command]
    if handler then
        local ok, err = pcall(handler, table.unpack(args, 2))
        print(ok and ("[ripple] " .. command .. " ok") or ("[ripple] " .. tostring(err)))
    end
end)

print("[Ripple] " .. tostring(#Commands) .. " commands ready")`;

const GARDEN_CODE = `-- Grow a Garden · Auto Plant & Harvest
local player = game.Players.LocalPlayer
local RS = game:GetService("ReplicatedStorage")

local Plants = { "Carrot", "Strawberry", "Blueberry", "Tomato" }
local Loop = true

local function getPlot()
    for _, plot in ipairs(workspace:GetChildren()) do
        local owner = plot:GetAttribute("Owner")
        if owner == player.UserId or owner == player.Name then
            return plot
        end
    end
    return nil
end

local plantRemote = RS:FindFirstChild("PlantSeed") or RS:FindFirstChild("Remotes") and RS.Remotes:FindFirstChild("Plant")
local harvestRemote = RS:FindFirstChild("Harvest") or RS:FindFirstChild("Remotes") and RS.Remotes:FindFirstChild("Harvest")

task.spawn(function()
    while Loop do
        local plot = getPlot()
        if plot then
            for index = 1, 8 do
                local seed = Plants[(index % #Plants) + 1]
                if plantRemote and seed then
                    plantRemote:FireServer(plot, seed, index)
                end
            end
            task.wait(2)
            for _, crop in ipairs(plot:GetDescendants()) do
                if crop:GetAttribute("Ready") == true and harvestRemote then
                    harvestRemote:FireServer(crop)
                end
            end
        end
        task.wait(0.8)
    end
end)

print("[Garden] auto plant loop started")`;

const DOORS_CODE = `-- DOORS · Visual Entity Alert
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")

local player = Players.LocalPlayer
local alerts = {}

local function makeAlert(name, position)
    local part = Instance.new("Part")
    part.Anchored = true
    part.CanCollide = false
    part.Size = Vector3.new(1, 1, 1)
    part.Transparency = 0.35
    part.Material = Enum.Material.Neon
    part.Color = Color3.fromRGB(200, 247, 90)
    part.Position = position
    part.Name = "doors_alert"
    part.Parent = workspace

    local gui = Instance.new("BillboardGui")
    gui.Size = UDim2.fromOffset(90, 26)
    gui.AlwaysOnTop = true
    gui.StudsOffsetWorldSpace = Vector3.new(0, 2, 0)
    gui.Parent = part

    local label = Instance.new("TextLabel")
    label.Size = UDim2.fromScale(1, 1)
    label.BackgroundTransparency = 1
    label.Text = name
    label.TextColor3 = Color3.fromRGB(255, 255, 255)
    label.TextStrokeTransparency = 0.4
    label.Font = Enum.Font.GothamBold
    label.TextSize = 14
    label.Parent = gui

    task.delay(6, function() part:Destroy() end)
    return part
end

RunService.Heartbeat:Connect(function()
    for _, entity in ipairs(workspace:GetChildren()) do
        local humanoid = entity:FindFirstChildOfClass("Humanoid")
        if humanoid and not Players:GetPlayerFromCharacter(entity) and not alerts[entity] then
            alerts[entity] = true
            makeAlert(entity.Name, humanoid.RootPart and humanoid.RootPart.Position or Vector3.zero)
        end
    end
end)

print("[DOORS] entity watcher online")`;

const NOW = Date.now();
const DAY = 86_400_000;

const seedScripts: NewScript[] = [
  {
    slug: "orbit-esp-9f3k",
    title: "Orbit ESP · 通用透视引擎",
    description:
      "轻量级通用 ESP 高亮库，支持玩家名字、距离与队伍检测。帧率友好，按需创建 BillboardGui，不会拖慢客户端。",
    code: ESP_CODE,
    language: "luau",
    tags: ["透视", "通用", "战斗"],
    authorName: "voidrunner",
    editKey: "seed-key-orbit-esp-0001",
    views: 48213,
    runs: 92144,
    likes: 1862,
    createdAt: new Date(NOW - 2 * DAY),
    updatedAt: new Date(NOW - 6 * 3_600_000),
  },
  {
    slug: "blox-fruits-autofarm-72mx",
    title: "Blox Fruits · 自动刷果实",
    description:
      "自动识别最近的敌人并执行连击，带任务自动接取与安全模式。所有远程调用均做存在性校验，适配最新版本。",
    code: FARM_CODE,
    language: "luau",
    tags: ["自动", "Blox Fruits", "战斗"],
    authorName: "luaforge",
    editKey: "seed-key-blox-farm-0002",
    views: 912408,
    runs: 1_702_233,
    likes: 5291,
    createdAt: new Date(NOW - 11 * DAY),
    updatedAt: new Date(NOW - 2 * DAY),
  },
  {
    slug: "lucid-ui-library-18kb",
    title: "Lucid UI · 18kb 轻量窗口库",
    description:
      "给脚本作者使用的现代 UI 库：窗口拖动、标签页、通知、主题变量。单文件、零依赖，直接 require 或内联托管均可。",
    code: UI_CODE,
    language: "luau",
    tags: ["工具", "UI", "库"],
    authorName: "kiwi",
    editKey: "seed-key-lucid-ui-0003",
    views: 33487,
    runs: 51009,
    likes: 2318,
    createdAt: new Date(NOW - 4 * DAY),
    updatedAt: new Date(NOW - 20 * 3_600_000),
  },
  {
    slug: "ps99-auto-hatch-5c1a",
    title: "Pet Simulator 99 · 自动开箱",
    description:
      "自动扫描可用蛋并循环孵化，自动清理普通宠物，支持通知输出。带防卡死心跳，长时间挂机更稳定。",
    code: PETS_CODE,
    language: "luau",
    tags: ["自动", "模拟器", "宠物"],
    authorName: "sunnydev",
    editKey: "seed-key-ps99-hatch-0004",
    views: 267915,
    runs: 604771,
    likes: 3120,
    createdAt: new Date(NOW - 6 * DAY),
    updatedAt: new Date(NOW - 3 * DAY),
  },
  {
    slug: "spectre-smooth-aim-8zq2",
    title: "Spectre · 平滑镜头自瞄",
    description:
      "基于视口距离的平滑瞄准辅助，可调节 FOV、平滑系数与队伍检测。使用 CFrame:Lerp 过渡，镜头不会出现跳变。",
    code: AIM_CODE,
    language: "luau",
    tags: ["射击", "战斗", "FPS"],
    authorName: "raycast",
    editKey: "seed-key-spectre-aim-0005",
    views: 155204,
    runs: 318902,
    likes: 1499,
    createdAt: new Date(NOW - 9 * DAY),
    updatedAt: new Date(NOW - 4 * DAY),
  },
  {
    slug: "ripple-admin-panel-0b4d",
    title: "Ripple Admin · 通用管理面板",
    description:
      "通过聊天前缀调用的轻量管理面板，内置移动速度、跳跃、传送、清除地图物件等 12 个命令，轻松扩展。",
    code: ADMIN_CODE,
    language: "luau",
    tags: ["管理员", "通用", "工具"],
    authorName: "voidrunner",
    editKey: "seed-key-ripple-admin-0006",
    views: 421770,
    runs: 887310,
    likes: 2784,
    createdAt: new Date(NOW - 16 * DAY),
    updatedAt: new Date(NOW - 8 * DAY),
  },
  {
    slug: "grow-a-garden-auto-3j9s",
    title: "Grow a Garden · 自动种植",
    description:
      "自动识别自己的地块，循环播种与收获。支持作物轮换，稳定不掉帧，适合长时间后台挂机。",
    code: GARDEN_CODE,
    language: "luau",
    tags: ["自动", "模拟器", "Grow a Garden"],
    authorName: "kiwi",
    editKey: "seed-key-garden-auto-0007",
    views: 289411,
    runs: 712009,
    likes: 2544,
    createdAt: new Date(NOW - 1 * DAY),
    updatedAt: new Date(NOW - 5 * 3_600_000),
  },
  {
    slug: "doors-entity-alert-h7p8",
    title: "DOORS · 实体预警标记",
    description:
      "扫描工作区中的非玩家 Humanoid，并用霓虹标记 + BillboardGui 提示实体位置，六秒后自动销毁。",
    code: DOORS_CODE,
    language: "luau",
    tags: ["恐怖", "辅助", "DOORS"],
    authorName: "raycast",
    editKey: "seed-key-doors-alert-0008",
    views: 19803,
    runs: 41220,
    likes: 812,
    createdAt: new Date(NOW - 13 * 3_600_000),
    updatedAt: new Date(NOW - 9 * 3_600_000),
  },
];

const seedComments = [
  {
    slug: "orbit-esp-9f3k",
    authorName: "kiwi",
    body: "在 Delta 里跑了一晚上很稳，建议加个队伍颜色开关。",
    minutesAgo: 180,
  },
  {
    slug: "orbit-esp-9f3k",
    authorName: "raycast",
    body: "用 task.defer 替代 wait 会更丝滑，其他都很棒。",
    minutesAgo: 1480,
  },
  {
    slug: "blox-fruits-autofarm-72mx",
    authorName: "sunnydev",
    body: "自动接任务那一段太省心了，三档延迟都测试过没问题。",
    minutesAgo: 620,
  },
  {
    slug: "blox-fruits-autofarm-72mx",
    authorName: "匿名",
    body: "loadstring 一次就成功，raw 接口速度也很快。",
    minutesAgo: 240,
  },
  {
    slug: "lucid-ui-library-18kb",
    authorName: "voidrunner",
    body: "18kb 能做成这样真的强，准备把自己的面板迁过来。",
    minutesAgo: 430,
  },
  {
    slug: "ps99-auto-hatch-5c1a",
    authorName: "mochi",
    body: "挂机两小时没有掉线，开箱速度可以自己改。",
    minutesAgo: 90,
  },
  {
    slug: "spectre-smooth-aim-8zq2",
    authorName: "nori",
    body: "0.18 的平滑度手感刚好，记得把 teamCheck 打开。",
    minutesAgo: 1150,
  },
  {
    slug: "ripple-admin-panel-0b4d",
    authorName: "luaforge",
    body: "用 string.split 处理参数写得很干净，已收藏。",
    minutesAgo: 2600,
  },
];

const ADMIN_USERNAME = (process.env.ADMIN_USERNAME ?? "zasqw89071").toLowerCase();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? "zasqw890";

/** Extra admins, comma separated. Defaults include the second creator account. */
const EXTRA_ADMINS = (process.env.ADMIN_USERNAMES ?? "lqnb")
  .split(",")
  .map((name) => name.trim().toLowerCase())
  .filter(Boolean);

/**
 * Make sure the creator account exists and owns the site.
 * Password comes from env when provided, otherwise the configured default.
 */
async function ensureAdminUser(): Promise<void> {
  try {
    const rows = await db
      .select({ id: users.id, role: users.role, passwordHash: users.passwordHash })
      .from(users)
      .where(eq(users.username, ADMIN_USERNAME))
      .limit(1);

    if (rows[0]) {
      const patch: { role?: string; passwordHash?: string } = {};
      if (rows[0].role !== "admin") patch.role = "admin";
      // Keep the documented creator credentials working after a fresh import.
      if (!(await verifyPassword(ADMIN_PASSWORD, rows[0].passwordHash))) {
        patch.passwordHash = await hashPassword(ADMIN_PASSWORD);
      }
      if (Object.keys(patch).length > 0) {
        await db.update(users).set(patch).where(eq(users.id, rows[0].id));
      }
      return;
    }

    await db
      .insert(users)
      .values({
        username: ADMIN_USERNAME,
        passwordHash: await hashPassword(ADMIN_PASSWORD),
        role: "admin",
      })
      .onConflictDoNothing();
  } catch (error) {
    console.error("[seed] admin user failed", error);
  }
}

/** Promote existing accounts listed in ADMIN_USERNAMES, creating them if needed. */
async function ensureExtraAdmins(): Promise<void> {
  for (const username of EXTRA_ADMINS) {
    if (username === ADMIN_USERNAME) continue;
    try {
      const rows = await db
        .select({ id: users.id, role: users.role })
        .from(users)
        .where(eq(users.username, username))
        .limit(1);

      if (rows[0]) {
        if (rows[0].role !== "admin") {
          await db.update(users).set({ role: "admin" }).where(eq(users.id, rows[0].id));
        }
        continue;
      }

      await db
        .insert(users)
        .values({
          username,
          role: "admin",
          passwordHash: await hashPassword("loadbin-admin"),
        })
        .onConflictDoNothing();
    } catch (error) {
      console.error(`[seed] extra admin ${username} failed`, error);
    }
  }
}

async function ensureSettings(): Promise<void> {
  await db.insert(siteSettings).values({ id: 1 }).onConflictDoNothing();
}

let seedPromise: Promise<void> | null = null;

async function insertComments(): Promise<void> {
  const [row] = await db.select({ count: sql<number>`count(*)::int` }).from(comments);
  if ((row?.count ?? 0) > 0) return;

  const slugs = [...new Set(seedComments.map((comment) => comment.slug))];
  const rows = await db
    .select({ id: scripts.id, slug: scripts.slug })
    .from(scripts)
    .where(inArray(scripts.slug, slugs));

  const idBySlug = new Map(rows.map((item) => [item.slug, item.id]));

  const values = seedComments.flatMap((comment) => {
    const scriptId = idBySlug.get(comment.slug);
    if (!scriptId) return [];
    return [
      {
        scriptId,
        authorName: comment.authorName,
        body: comment.body,
        createdAt: new Date(Date.now() - comment.minutesAgo * 60_000),
      },
    ];
  });

  if (values.length > 0) await db.insert(comments).values(values);
}

async function insertSeed(): Promise<void> {
  const [row] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(scripts);

  if ((row?.count ?? 0) === 0) {
    await db.insert(scripts).values(seedScripts).onConflictDoNothing({ target: scripts.slug });
  }

  await insertComments();
  await ensureSettings();
  await ensureAdminUser();
  await ensureExtraAdmins();
}

export function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = insertSeed().catch((error) => {
      console.error("[seed] failed", error);
      seedPromise = null;
    });
  }
  return seedPromise;
}
