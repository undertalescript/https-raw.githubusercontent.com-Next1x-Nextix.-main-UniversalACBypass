import { headers } from "next/headers";

/**
 * Resolve the public origin of the current request so the generated
 * loadstring URL always matches the domain the visitor is browsing on.
 */
export async function getBaseUrl(): Promise<string> {
  const envUrl = process.env.NEXT_PUBLIC_SITE_URL ?? process.env.SITE_URL;
  if (envUrl) return envUrl.replace(/\/$/, "");

  try {
    const store = await headers();
    const host = store.get("x-forwarded-host") ?? store.get("host");
    if (host) {
      const isLocal = /^(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?$/.test(host);
      // Prefer https for any non-local host so generated loadstring URLs stay valid
      // behind the preview proxy (which may forward `http`).
      const proto = isLocal ? "http" : "https";
      return `${proto}://${host}`;
    }
  } catch {
    // headers() is unavailable outside a request scope (build time / scripts)
  }

  return "http://localhost:3000";
}

/** Protected endpoint. Without `key` it answers 403 — it is not a shareable link. */
export function rawUrlFor(baseUrl: string, slug: string, accessToken: string, alias = "api/raw"): string {
  return `${baseUrl}/${alias}/${slug}?key=${accessToken}`;
}

/** Signature carried in the path — survives executors that strip query strings. */
export function pathUrlFor(baseUrl: string, slug: string, accessToken: string): string {
  return `${baseUrl}/k/${accessToken}/${slug}`;
}

export function pageUrlFor(baseUrl: string, slug: string): string {
  return `${baseUrl}/s/${slug}`;
}

export type LoaderVariant = "stable" | "loadstring" | "async" | "request" | "luau";

export function loadstringFor(
  baseUrl: string,
  slug: string,
  accessToken: string,
  variant: LoaderVariant = "stable",
): string {
  const url = rawUrlFor(baseUrl, slug, accessToken);
  switch (variant) {
    case "stable":
      // Default: never throws, prints a readable Chinese reason in the console.
      return `local ok, source = pcall(function()
    return game:HttpGet("${url}")
end)

if not ok or not source then
    return warn("[loadbin] 加载失败: " .. tostring(source))
end

local chunk, err = loadstring(source)
if not chunk then
    return warn("[loadbin] 语法错误: " .. tostring(err))
end

chunk()`;
    case "async":
      return `loadstring(game:HttpGetAsync("${url}"))()`;
    case "request":
      return `local res = request({\n    Url = "${url}",\n    Method = "GET",\n    Headers = { ["User-Agent"] = "Roblox/WinInet" },\n})\n\nloadstring(res.Body)()`;
    case "luau":
      return `local source = game:HttpGet("${url}")\nlocal chunk, err = loadstring(source)\n\nif not chunk then\n    return warn("[loadbin] " .. tostring(err))\nend\n\nchunk()`;
    default:
      return `loadstring(game:HttpGet("${url}"))()`;
  }
}
