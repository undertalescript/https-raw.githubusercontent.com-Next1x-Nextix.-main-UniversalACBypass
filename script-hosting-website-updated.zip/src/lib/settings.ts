import { eq } from "drizzle-orm";
import { db } from "@/db";
import { siteSettings, type SiteSettings } from "@/db/schema";

const SETTINGS_ID = 1;

export const DEFAULT_SETTINGS: SiteSettings = {
  id: SETTINGS_ID,
  scriptsEnabled: true,
  maintenanceMode: false,
  announcement: "",
  updatedAt: new Date(0),
  updatedBy: null,
};

/** Read the single settings row, creating it lazily. Never throws. */
export async function getSiteSettings(): Promise<SiteSettings> {
  try {
    const rows = await db
      .select()
      .from(siteSettings)
      .where(eq(siteSettings.id, SETTINGS_ID))
      .limit(1);

    if (rows[0]) return rows[0];

    const [created] = await db
      .insert(siteSettings)
      .values({ id: SETTINGS_ID })
      .onConflictDoNothing()
      .returning();

    return created ?? DEFAULT_SETTINGS;
  } catch (error) {
    console.error("[settings] read failed, defaulting to enabled", error);
    return DEFAULT_SETTINGS;
  }
}

export async function updateSiteSettings(patch: {
  scriptsEnabled?: boolean;
  maintenanceMode?: boolean;
  announcement?: string;
  updatedBy?: string;
}): Promise<SiteSettings> {
  await getSiteSettings();

  const [updated] = await db
    .update(siteSettings)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(siteSettings.id, SETTINGS_ID))
    .returning();

  return updated ?? DEFAULT_SETTINGS;
}

/** Master switch used by the raw endpoint: false ⇒ nothing can execute. */
export async function areScriptsEnabled(): Promise<boolean> {
  const settings = await getSiteSettings();
  return settings.scriptsEnabled;
}
