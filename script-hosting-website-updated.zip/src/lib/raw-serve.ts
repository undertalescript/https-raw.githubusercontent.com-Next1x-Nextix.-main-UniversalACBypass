import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { scripts } from "@/db/schema";
import { normalizeInflation, obfuscate, normalizeObfuscation } from "@/lib/obfuscate";
import { buildStagedBundle, stageNonce } from "@/lib/stage";
import { getSessionUser, isAdminUser } from "@/lib/auth";
import { getBaseUrl } from "@/lib/site";
import { areScriptsEnabled } from "@/lib/settings";

const BASE_HEADERS: Record<string, string> = {
  "cache-control": "no-store, no-cache, must-revalidate",
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, HEAD, OPTIONS",
  "access-control-allow-headers": "*",
  "x-content-type-options": "nosniff",
  "x-robots-tag": "noindex, nofollow, noarchive",
};

/**
 * Only *real browser navigations* are refused.
 * Executors often spoof a Chrome UA, so we must NOT judge by User-Agent —
 * we look at the fetch metadata / accept headers a browser always sends.
 */
function isBrowserNavigation(request: Request): boolean {
  const mode = (request.headers.get("sec-fetch-mode") ?? "").toLowerCase();
  const dest = (request.headers.get("sec-fetch-dest") ?? "").toLowerCase();
  const accept = (request.headers.get("accept") ?? "").toLowerCase();
  const upgrade = request.headers.get("upgrade-insecure-requests");
  const purpose = (request.headers.get("purpose") ?? "").toLowerCase();

  if (mode === "navigate") return true;
  if (dest === "document" || dest === "iframe") return true;
  if (accept.includes("text/html") || accept.includes("application/xhtml")) return true;
  if (upgrade === "1") return true;
  if (purpose === "prefetch" || purpose === "preview") return true;
  return false;
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function escapeLua(value: string): string {
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

function textHeaders(extra: Record<string, string> = {}): Record<string, string> {
  return { ...BASE_HEADERS, "content-type": "text/plain; charset=utf-8", ...extra };
}

/**
 * Executor-friendly failure: HTTP 200 with a Lua `warn(...)` so the user sees a
 * readable message in the console instead of a bare "HTTP 403" stack trace.
 * No source code is ever included here.
 */
function luaWarn(message: string, headers: Record<string, string> = {}): Response {
  const body = `warn("[loadbin] ${escapeLua(message)}")`;
  return new Response(body, { status: 200, headers: textHeaders(headers) });
}

function protectionPage(input: { status: number; title: string; message: string; slug: string }): Response {
  const html = `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>${escapeHtml(input.title)} · loadbin 源码保护</title>
<meta name="robots" content="noindex,nofollow"/>
<style>
:root{color-scheme:dark}
*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:grid;place-items:center;background:#06070b;color:#d9dbe7;font-family:Inter,"PingFang SC","Microsoft YaHei",system-ui,sans-serif;padding:24px}
.card{width:100%;max-width:490px;border:1px solid #1e2030;border-radius:16px;background:linear-gradient(160deg,#101119,#08090f);padding:28px;text-align:center}
.icon{display:grid;place-items:center;width:46px;height:46px;margin:0 auto;border-radius:13px;border:1px solid rgba(248,113,113,.35);background:rgba(248,113,113,.1);font-size:20px}
.eyebrow{margin:16px 0 0;font:11px ui-monospace,monospace;letter-spacing:.18em;text-transform:uppercase;color:#f87171}
h1{font-size:19px;margin:8px 0 0;color:#fff;line-height:1.4}
p{font-size:13px;line-height:1.75;color:#82869c;margin:10px 0 0}
code{font-family:ui-monospace,monospace;color:#a78bfa;background:rgba(139,92,246,.12);border:1px solid rgba(139,92,246,.25);border-radius:6px;padding:1px 5px;word-break:break-all}
.row{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-top:18px}
a{display:inline-block;padding:9px 14px;border-radius:9px;border:1px solid #1e2030;color:#d9dbe7;text-decoration:none;font-size:12.5px;background:#0d0e16}
a.p{background:linear-gradient(135deg,#8b5cf6,#6d3ff0);border-color:rgba(167,139,250,.5);color:#fff}
.foot{margin-top:16px;font:11px ui-monospace,monospace;color:#4b4e63}
</style></head>
<body><div class="card">
<div class="icon">🔒</div>
<p class="eyebrow">403 · source protected</p>
<h1>${escapeHtml(input.title)}</h1>
<p>${escapeHtml(input.message)}</p>
<p>源码地址只允许脚本执行器通过带签名的 <code>loadstring</code> 读取，直接打开或复制到浏览器会被拒绝。</p>
<div class="row">
  <a class="p" href="/s/${escapeHtml(input.slug)}">返回脚本页面</a>
  <a href="/docs#protection">了解源码保护</a>
</div>
<div class="foot">loadbin · protected source endpoint</div>
</div></body></html>`;

  return new Response(html, {
    status: input.status,
    headers: { ...BASE_HEADERS, "content-type": "text/html; charset=utf-8" },
  });
}

export async function serveRawScript(
  request: Request,
  rawSlug: string,
  pathKey?: string,
): Promise<Response> {
  const slug = rawSlug.replace(/\.lua$/i, "").slice(0, 80);
  const url = new URL(request.url);
  const key = (pathKey ?? url.searchParams.get("key") ?? url.searchParams.get("token") ?? "").trim();

  // 1) Browser / preview-panel navigation → hard refusal, never any source.
  if (isBrowserNavigation(request)) {
    return protectionPage({
      status: 403,
      title: "禁止直接访问源码",
      message: "你正在浏览器中直接打开脚本源码地址，该请求已被源码保护拦截。",
      slug,
    });
  }

  try {
    const rows = await db
      .select({
        id: scripts.id,
        code: scripts.code,
        runs: scripts.runs,
        accessToken: scripts.accessToken,
        ownerId: scripts.ownerId,
        sourceProtected: scripts.sourceProtected,
        disabled: scripts.disabled,
        obfuscation: scripts.obfuscation,
        inflation: scripts.inflation,
      })
      .from(scripts)
      .where(eq(scripts.slug, slug))
      .limit(1);

    const script = rows[0];

    // 2) Site-wide kill switch (owner console).
    if (!(await areScriptsEnabled())) {
      return luaWarn("脚本执行已被站长暂停 (site owner disabled script execution)。请稍后再试。", {
        "retry-after": "60",
      });
    }

    // 3) Unknown slug.
    if (!script) {
      return luaWarn(`脚本不存在或已被删除: ${slug.replace(/[^a-z0-9-]/gi, "")}`);
    }

    // 4) Blocked by the owner.
    if (script.disabled) {
      return luaWarn("该脚本已被站长停用 (disabled by the site owner)。");
    }

    // 5) Signature check — missing / wrong key explains itself in the console.
    if (script.sourceProtected && key !== script.accessToken) {
      return luaWarn(
        key
          ? "访问签名无效，请重新从脚本页面复制完整 loadstring。"
          : "缺少访问签名 ?key=…，请复制脚本页面提供的完整 loadstring，而不是裸链接。",
      );
    }

    // 6) Only executors reach this point: count the run and return the payload.
    if (request.method !== "HEAD") {
      await db
        .update(scripts)
        .set({ runs: sql`${scripts.runs} + 1` })
        .where(eq(scripts.id, script.id));
    }

    const mode = normalizeObfuscation(script.obfuscation);
    // `plain=1` (unobfuscated build) is restricted to the author / site owner.
    let wantPlain = url.searchParams.get("plain") === "1";
    if (wantPlain && mode !== "none") {
      const viewer = await getSessionUser();
      const allowed = Boolean(viewer && (viewer.id === script.ownerId || isAdminUser(viewer)));
      if (!allowed) wantPlain = false;
    }
    const inflation = normalizeInflation(script.inflation);
    // Behind the preview proxy `url.origin` is the internal bind address,
    // so the public host must come from the forwarded headers.
    const origin = await getBaseUrl();
    const nonce = stageNonce(slug, script.accessToken);
    const stageUrl = `${origin}/api/stage/${slug}?key=${encodeURIComponent(key)}&n=${nonce}`;
    const bundle = wantPlain
      ? { stub: script.code, stage: "" }
      : buildStagedBundle({
          slug,
          code: script.code,
          accessToken: script.accessToken,
          nonce,
          obfuscation: mode,
          inflation,
          stageUrl,
        });
    const payload = bundle.stub;

    return new Response(request.method === "HEAD" ? null : payload, {
      status: 200,
      headers: textHeaders({
        "content-length": String(Buffer.byteLength(payload)),
        "x-loadbin-status": "ok",
        "x-loadbin-obfuscation": mode,
        "x-loadbin-inflation": String(inflation),
      }),
    });
  } catch (error) {
    console.error("[raw] failed", error);
    return luaWarn("服务端暂时不可用，请稍后重试 (upstream error)。", { "retry-after": "5" });
  }
}

export function rawPreflight(): Response {
  return new Response(null, { status: 204, headers: BASE_HEADERS });
}
